

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>

<script src="assets/js/app.js"></script>
<h3 class='card-header bg-white'> <center>ADD NEW CUSTOMERS DETAILS</center></h3>
<div class='card-body'>
    <div class="jumbotron"> 
    <div class="container">
        
<form action="" class="bg-light needs-validation m-3" novalidate method="post" >
           
            
            <div class="row ">

                <div class="col-6">
                     
                    <div class="form-group">
                <label for="validationCustom01">Phone number</label>
                <input type="text" id="validationCustom01" class="form-control " placeholder="Fullname" aria-describedby="helpId" required name="phone">
                <br>
                 <div class="col-6">
                <label for="validationCustom01">Message</label>
                <textarea name="text" rows="70"></textarea> 
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter address
                </div>
              </div>
            </div>
          </div>
          </div>
          </form>
      </div>
  </div>
</div>
</div>
</body>
</html>