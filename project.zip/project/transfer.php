<?php
error_reporting(0);
include 'auth.php';
include 'model/db_connection.php';
include 'model/userModel.php';
include('connect/connect.php');
$id_cash = $_SESSION['cash'];
if (isset($_GET['idcheck'])) {
  echo "<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Your product is less you can never transfer'
    data-type='warning'>
    </div>";
}
if (isset($_GET['text'])) {
   echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Your product is Successfully transfered to another branch'
    data-type='success'> 
    </div>";
  }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
   <?php 

    if ($id_cash =='invetory') {
       include 'includes/inventorynav.php'; 
    }else{
        include 'includes/nav.php'; 
    }
    

    ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center> 
                        </h1>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
             <div class='card my-3 no-b'>
                
                 <div class='card-body'>
                    <div class="table-responsive">
                        <center><h4 class="card-header">MANAGE YOUR EXPENSE HERE</h4></center><br>
                        <table id="example2" class="table table-bordered table-hover data-tables"
                               data-options='{ "paging": false; "searching":false}'>
                              
                            <thead>
                                 <tr>
                               <th>S/N</th>
                                <th>Product name</th>
                                     <th>Branch Name</th>
                                     <th>Amount</th>
                                     <th>select_branch</th>
                                    <th>Amount_to_transfer</th>
                                     <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                  <?php

                                  $userone = "SELECT * FROM tranfer join branch on tranfer.now_branch = branch.id join products on products.product_id = tranfer.id_product";
                                $resultsone = mysqli_query($conn,$user);

                              $user = "SELECT * FROM Products join branch on Products.id_branch = branch.id";
                              $results = mysqli_query($conn,$user);
                              
                              $x = 1;
                            
                              while ($value = mysqli_fetch_array($results)) { 

                              if ( $value['quantinty'] > 10) {?>
                                <tr>
                                  <td><?php echo $x ?></td>
                                  <td><?php echo $value['prod_name']; ?></td>
                                  <td><?php echo $value['branch_name']; ?></td>
                                   <td><?php echo $value['quantinty']; ?></td>

                                <form method="POST" action="trnsfer_pro.php">
                                    <td><select class="form-control" name="branch">
                                    <?php   
                                      $sql1 = "SELECT * FROM branch";
                                      $results1 = mysqli_query($conn,$sql1);
                                      while ($fecth1 = mysqli_fetch_array($results1)) {?>
                                         <option value="<?php   echo $fecth1['id']; ?>"><?php  echo $fecth1['branch_name'] ?></option>
                                     <?php }
                                     ?> 
                                          
                                    </select></td>
                                     <td><input type="" name="qty" class="form-control">
                                      <input type="hidden" name="pre" value="<?php  echo $value['id_branch']; ?>" >
                                      <input type="hidden" name="id_pro" value="<?php   echo $value['product_id']; ?>"  >
                                     </td>
                                     <td> <input type="submit" name="btn" class="btn btn-success" value="Transfer Product" ></td>
                                     </form>
                                </tr>
                                    
                                 <?php  }
                             
                         

                            $x++;

                           }

                           ?>

                              
                        
                            </tbody>
                            <tfoot>
                                 <tr>
                               <th>S/N</th>
                                <th>Product name</th>
                                     <th>Branch Name</th>
                                     <th>Amount</th>
                                     <th>select_branch</th>
                                    <th>Amount_to_transfer</th>
                                     <th>Action</th>
                            </tr>
                            </tfoot>
                        </table>
                        </div>

                 </div>
            </div>
        </div>
    </div> 
</body>
<script src="assets/js/app.js"></script>

 <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'idy=' + del_id;
 if(confirm("Are you sure want to delete? There is NO undo!"))
      {

 $.ajax({
   type: "GET",
   url: "delete_customer.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
    .animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>
 

</html>