<?php
session_start();
error_reporting(0);
include "model/db_connection.php";
include "model/userModel.php";
include "connect/connect.php";

if (isset($_GET['ujumbe'])) {
   echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Successfully LogOut'
    data-type='success'> 
    </div>";
     echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Thank you fo using our system'
    data-type='success'> 
    </div>";

  }


if (isset($_GET['reset_message'])) {

   echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='We have already send token for login please Check your message for token in order to login'
    data-type='info'> 
    </div>";
}
if (isset($_GET['reset_error'])) {

   echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Reset password Error Try again '
    data-type='error'> 
    </div>";
}

if (isset($_POST['login'])) {
$email = $_POST['email'];
$pass = $_POST['password'];

$login = new userModel;
$check = $login -> loginInfo($email,$pass);
$id_branch = $check['branch_id'];

$position = $check['position'];
 $time= date("h:i:sa");
 $action='Login Successfully';
switch ($position) {
  case 'cashier':
     header('location:dashboardcash.php?login=success');
    $_SESSION['inv'] = $id_branch ;
    $_SESSION['email'] = $email;
    $_SESSION['cash'] = $position;
    $uip=$_SERVER['REMOTE_ADDR']; // get the user ip
// query for inser user log in to data base
mysqli_query($conn,"INSERT INTO `userlog` (`position`, `ip`, `action`,`stamp`) 
VALUES ('".$_SESSION['cash']."','$uip', '$action','$time')");
    break;

    case 'invetory':
    header('location:dashboardinv.php?login=success');
    $_SESSION['inv'] = $id_branch;
    $_SESSION['email'] = $email;
    $_SESSION['cash'] = $position;
     $uip=$_SERVER['REMOTE_ADDR'];
mysqli_query($conn,"INSERT INTO `userlog` (`position`, `ip`, `action`,`stamp`) 
VALUES ('".$_SESSION['inv']."','$uip', '$action','$time')");
    break;

    case 'admin':
    header('location:home.php?login=success');
    $_SESSION['email'] = $email;
    $uip=$_SERVER['REMOTE_ADDR'];
mysqli_query($conn,"INSERT INTO `userlog` (`position`, `ip`, `action`,`stamp`) 
VALUES ('".$_SESSION['email']."','$uip', '$action','$time')");
    break;
  
  default:
   echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Wrong Username Or password'
    data-type='error'> 
    </div>";
    break;
}

}
    
?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEMS</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/app.css">

</head>
<body class="light sidebar-mini sidebar-collapse">

<div id="app">
<main>
    <div id="primary" class="p-t-b-40 height-full bg-light">
        <div class="container " >
            <div class="row">
                <div class="col-lg-4 mx-md-auto paper-card ">
                    <div class="text-center mb-4">
                        <h3 class="" style="color: #4600A0">PRODUCT INFORMATION TRACKING SYSTEM</h3>
                         <center><h4 class="card-header" style="color: #04600A;">
                          <img src="image/images.jpg">
                                              <br> 
                                      <h6 class="mt-2" style="color: #4600A0" >Welcome Again</h6>
                        <p></p>
                      
                    </div>
                    <form action="index.php" method="POST">
                        <div class="form-group has-icon"><i class="icon-envelope-o"></i>
                            <input type="email" class="form-control form-control-lg"
                                   placeholder="Enter Email" name="email" required>
                        </div>
                        <div class="form-group has-icon"><i class="icon-user-secret"></i>
                            <input type="password" class="form-control form-control-lg"
                                   placeholder="Enter password " name="password" required>
                        </div>
                     
                        <button type="submit" name="login" class="btn bg-secondary btn-lg btn-block text-white">Login</button>
                        <p></p>
                        <p class="forget-pass"><h6><spans tyle="color: #4600A">Forgot password?</span> <a href="forgot.php">Click here</a></h6></p> 

                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- #primary -->
</main>

</div>
<!--/#app -->
<script src="assets/js/app.js"></script>

</body>
</html>