<?php
include"auth.php";
include('model/db_connection.php');
include('model/userModel.php');
require('fpdf/fpdf/fpdf.php');
include('connect/connect.php');
$pdf = new FPDF();
$pdf->AddPage('P','A3','mm');
$pdf->SetFont('Arial','',10);
$pdf->SetFont('Arial','B',20);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(260,10,'',0,1,'C');
$pdf->Cell(260,30,'PRODUCT INFORMATION TRACKING SYSTEM',0,1,'C');
$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(260,10,'REPORT OF ALLPRODUCT',0,1,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'No',1,0,'C');
$pdf->Cell(40,10,'PRODUCT CODE ',1,0,'C');
$pdf->Cell(60,10,' NAME  ',1,0,'C');
$pdf->Cell(15,10,'QYT',1,0,'C');
$pdf->Cell(28,10,'EXPIRE DATE ',1,0,'C');
$pdf->Cell(28,10,' BRANCH NAME',1,0,'C');
$pdf->Cell(100,10,' INGREDIENT1',1,1,'C');

$tarehe= date('d-m-Y');
$user = new userModel();
$datauser = $user->getProduct();
$x = 1;
foreach ($datauser as $row) {
$pdf->SetFont('Arial','',10);
$pdf->Cell(10,10,$x,1,0,'C');
$pdf->Cell(40,10,$row['product_code'],1,0,'C');
$pdf->Cell(60,10,$row['prod_name'],1,0,'L');
$pdf->Cell(15,10,$row['quantinty'],1,0,'R');
$pdf->SetTextColor(255,0,0);
$pdf->Cell(28,10,$row['expiry_date'],1,0,'R');
$pdf->SetTextColor(0,0,0);
$pdf->Cell(28,10,$row['branch_name'],1,0,'C'); 
$pdf->Cell(100,10,$row['ingredient'],1,1,'L');
$pdf->SetTextColor(0,0,0);
$x++;
}
$pdf->Cell(70,20,'',0,1,'C');
$pdf->SetFont('Arial','',17);
$pdf->Cell(200,10,'Report on date: '.date('l-d-m-y'),0,1);
$pdf->Output();

?>