<?php
include('classess/db_connection.php');
include('classess/userModel.php');
require('fpdf/fpdf/fpdf.php');
include("auth.php");
include('connect/connect.php');
$dataWaumini = new userModel();
$pdf = new FPDF();
$pdf->AddPage('l','A4','mm');

// $pdf->Cell(40,10,'Helgygcduycgudygcvyugfvyu',1,0,1,'C');
$pdf->SetFont('Arial','',10);
// Move to 8 cm to the right
$pdf->SetFont('Arial','B',20);
$pdf->SetTextColor(238,130,238);
// Centered text in a framed 20*10 mm cell and line break
// $pdf->Image('image/download1.png',10,10,-300); 

$pdf->Cell(260,10,'',0,1,'C');
$pdf->Cell(260,10,'ALL EXPENSES REPORTS',0,1,'C');

$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,0,0);
// Centered text in a framed 20*10 mm cell and line break
$pdf->Cell(260,30,'AHADI NA JENGO ZA WAUMINI',0,1,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'No',1,0,'C');
$pdf->Cell(40,10,'BAHASHA',1,0,'C');
//$pdf->Cell(60,10,'FULLNAME',1,0,'C');
$pdf->Cell(60,10,'AHADI  ',1,0,'C');
$pdf->Cell(60,10,'JENGO  ',1,0,'C');
$pdf->Cell(40,10,'MUDA ',1,0,'C');
$pdf->Cell(65,10,'TAREHE',1,1,'C');
$tarehe= date('d-m-Y');

//  $select="SELECT matoleo.jengo as mat_jengo, matoleo.ahadi as mat_ahadi, agano.ahadi as agano_ahadi, agano.jengo as agano_jengo, matoleo.bahasha_namba 
//  as bahasha_namba, matoleo.tarehe as tarehe, orodha_kuu.jina as fullname
//  FROM matoleo join orodha_kuu on matoleo.bahasha_namba = orodha_kuu.id join agano
//  on agano.bahasha_namba = matoleo.bahasha_namba WHERE matoleo.tarehe = '$tarehe' ";

$select="SELECT * FROM expense join branch where expense.brnch_id=branch.id order by `date` desc";
$res=mysqli_query($conn,$select);
$x=1;
while($row = mysqli_fetch_array($res)){
$pdf->SetFont('Arial','',10);
$pdf->Cell(10,10,$x,1,0,'C');
$pdf->Cell(40,10,$row['bahasha_namba'],1,0,'C');
//$pdf->Cell(60,10,$row['fullname'],1,0,'C');
$pdf->Cell(60,10,$row['ahadi'],1,0,'R');
$pdf->Cell(60,10,$row['jengo'],1,0,'R');
$pdf->Cell(40,10,$row['time'],1,0,'R');

$pdf->Cell(65,10,$row['tarehe'],1,1,'R');


  

    
    
    
$x++;
}

$pdf->Cell(70,20,'',0,1,'C');
$pdf->SetFont('Arial','',17);
$waumini8=$waumini6+$waumini7;
$pdf->Cell(250,10,'jumla ya ahadi za : '.date('l-d-m-Y') . "  " . $waumini6,1,1);
$pdf->Cell(250,10,'jumla ya jengo za : '.date('l-d-m-Y').  "  ". $waumini7,1,1);
$pdf->Cell(250,10,'jumla ya agano za : '.date('l-d-m-Y'). "  " .$waumini8,1,1);
$pdf->Cell(200,10,'Report on date: '.date('l-d-m-y'),0,1);



$pdf->Output();

?>


