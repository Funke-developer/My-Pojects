<?php
error_reporting(0);
include("auth.php");
include('connect/connect.php');
include 'model/db_connection.php';
include("model/userModel.php");

$class=new userModel();
$data=$class->getCategory();
$datatax=$class->getTax();

$id_cash = $_SESSION['cash']; 
$codew = $_GET['id'];
$sql = "SELECT * FROM products WHERE product_id='$codew'";
$results = mysqli_query($conn,$sql);
$fetchproduct= mysqli_fetch_array($results);

   
if (isset($_POST['regtwo'])) {

$product_code = $_POST['code'];
$product_name = $_POST['name'];
$purchasing_price = $_POST['purchasing_price'];
$product_quantity = $_POST['product_quantity'];
$tax = $_POST['tax'];
$category= $_POST['category'];
$selling = $_POST['selling'];
$arrival = $_POST['arrival'];
$expire = $_POST['expire'];
$update="UPDATE `products` SET `product_code` = '$product_code',`prod_name` = '$product_name',`purscasing_price` = '$purchasing_price',`quantinty` = '$product_quantity ',`category_id` = '$category',`selling_price` = '$selling',`tax_id` = '$tax',`arrival` = '$arrival', `expiry_date` = '$expire'  WHERE `products`.`product_id` = '$codew'";

$result_update = mysqli_query($conn,$update);
if ($result_update) {
    header("location:manage_product.php");
}

}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
     <?php 

    if ($id_cash =='invetory') {
       include("includes/inventorynav.php");
    }else{
        include 'includes/nav.php'; 
    }
    

    ?>
        <div class='has-sidebar-left has-sidebar-tabs'>

<h3 class='card-header bg-white'> <center>UPDATE PRODUCTS DETAILS</center></h3>
<div class='card-body'>
	<div class="jumbotron">	
	<div class="container">
		
<form action="" class="bg-light needs-validation m-3" novalidate method="post" style="border: 1px purple" >
           
            <div class="container">
            	<center>
                	<h3 class='card-header bg-white'> <center>UPDATE PRODUCTS DETAILS</center></h3>
                     </center>
            <div class="row ">


                <div class="col-6">
                	
                    <div class="form-group">
                <label for="validationCustom01">Product Code number</label>

    
                <input type="text" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" name="code" value="<?php echo $fetchproduct['product_code'];  ?>" readonly>
            
            </div>
          </div>
          
                  <div class="col-6">
                     
                    <div class="form-group">
                <label for="validationCustom01">Product Name</label>
                <input type="text" name="name" id="validationCustom01" class="form-control " placeholder="Product Name" aria-describedby="helpId" required value="<?php echo $fetchproduct['prod_name'];  ?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter name
                </div>

            </div>
          </div>
            </div>

            <div class="row ">
                 <div class="col">
                     <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Purchasing price</label>
                <input type="text" name="purchasing_price" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required value="<?php echo $fetchproduct['purscasing_price'];  ?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter purchasing
                </div>

            </div>

                </div>
                 <div class="col">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Total Quanty</label>
                <input type="number" name="product_quantity" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required value="<?php echo $fetchproduct['quantinty'];  ?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  Jaza total
                </div>

            </div>


                </div>
            </div>
             <div class="row ">

                <div class="col-6">
                   
                    <div class="form-group">
                      
        
                <label for="validationCustom01">Enter Tax Type </label>
                <select class="form-control" name="tax" required>
                    <option selected disabled="on">Enter Tax Type</option>
                    <?php 
                foreach ($datatax as  $value) {
                    echo"
                       <option value=".$value['tax_id'].">".$value['tax_name']."</option>";
                
                }



                ?>
                </select>
                
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter date
                </div>

            </div>
          </div>
                
               
        
                 <div class="col">
            <div class="form-group">


                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Select Product Category</label>
                <select class="form-control" name="category" required="on">
                    <option selected disabled="on">Select Product Category</option>

                <?php 
                foreach ($data as  $value) {
                    echo"
                       <option value=".$value['category_id'].">".$value['category']."</option>";
                
                }

                ?>
                 
                </select>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter profit
                </div>

            </div>



               
            </div>
            
        
            <br>
            <hr>
           <div class="container">
  <div class="row ">
    <div class="col-4">
            <div class="form-group">
                <label for="validationCustom01">selling Price </label>
                <input type="number" name="selling" id="validationCustom01" class="form-control " placeholder="selling Price" aria-describedby="helpId" required  value="<?php echo $fetchproduct['selling_price'];  ?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter selling price
                </div>

            </div>

                </div>
        
                 <div class="col-4">
            <div class="form-group">
                <label for="validationCustom01">Arrival Date</label>
                <input type="text" name="arrival" id="validationCustom01" class="form-control " placeholder="profit" aria-describedby="helpId" required value="<?php echo $fetchproduct['arrival'];?>">>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter arrival date
                </div>

            </div>
            </div>
            
         <div class="col-4">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Expire date</label>
                <input type="TEXT" name="expire" id="validationCustom01" class="form-control " placeholder="profit" aria-describedby="helpId" required value="<?php echo $fetchproduct['expiry_date'];?>" >>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter expire date
                </div>

            </div>
        </div>



               
            </div>
            <br>
            <hr>
        </div>
</div>
<center>
<div class="container">
    <div class="form-group">
                <button class="btn btn-secondary  col-6"  name="regtwo" style="background-color: purple;opacity: 0.4">Submit Details</button>
                <div class="form-group"></div>
                <hr>
                </div>
            </div>
        </center>
            </div>
            <br>
        </form>
    </div>

    </div>
</div>

               <div class="jumbotron col-12">
                       
                            <?php include("footer.php");?>
                    </div>
<script src="assets/js/app.js"></script>
</body>
</html>
