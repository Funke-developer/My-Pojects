<?php
include 'auth.php';
include('connect/connect.php');
include 'model/db_connection.php';
include 'model/userModel.php';
$id_cash = $_SESSION['cash'];
$userbranch=$_SESSION['inv'];
$total=new userModel();
$customertotal=$total->getCustomerTotal();
$productTotal=$total->getProductTotal1($userbranch);
$getBranchTotal=$total->getBranchTotal();
$getTransfered=$total->getTransfered1($userbranch);
$getExpired=$total-> getProductExpired8($userbranch);
$getEmployeeTotal=$total->getEmployeeTotal1($userbranch);
$getSumExpense=$total->getSumExpense1($userbranch);
$getPurschasing=$total->getPurschasing8($userbranch);

$id = $_SESSION['inv'];
?>
 <!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/app.css"> 
    <style>
        .diproper{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            
            z-index: 1;
            height: 100vh;
            background-color: rgba(0,0,0, 0.6);
        }
    </style>
</head>
<body class="light sidebar-mini sidebar-collapse">
    <div class="has-sidebar-left has-sidebar-tabs">
    <?php include("includes/inventorynav.php");?>
<div class="card m-3  p-2" style=" box-shadow: 5px 5px 10px rgba(0,0,0, 0.1);">

      <center><h2 class="card-header white" style="text-transform: uppercase;">PRODUCT INFORMATION TRACKING SYSTEM(MAIN DASHBOARD)</h2></center>
    <div class="card-body ">
    <div class="row no-gutters my-3 white ">
        
                <div class="col-md-3 shadow">
                        <div class="p-5 bg-secondary text-white">
                                <h6 class="font-weight-normal s-14 ">AVAILABLE  PRODUCTS</h6>
                                <?php   

                                   $sqlpro_tra = "SELECT * FROM products WHERE id_branch = '$id'";
                                  $results_pro = mysqli_query($conn,$sqlpro_tra);
                                  $num_pro_numy = mysqli_num_rows($results_pro);

                                 ?>
                                <span class="s-48 font-weight-lighter text-primary sc-counter"><?php  echo $productTotal
                                ;?></span>
                                <div class="float-right">
                                        <!--<span class="icon icon-arrow_upward s-48"></span>-->
                                    </div>
                            </div>
                            <div class="row p-2 s-18 text-center">
                                <div class="col-6 b-r"> 
                                    <i class="icon icon-arrow_upward text-success mr-2"></i><div></div>
                                </div>
                                <div class="col-6"> 
                                        <i class="icon icon-arrow_downward text-danger mr-2"></i> <div></div>
                                </div>
                            </div>
                        </div>

                         <div class="col-md-3 shadow">
                        <div class="p-5 bg-success text-white">
                                <h6 class="font-weight-normal s-14 ">TRANSFERED PRODUCT UN APPROVED</h6>
                                <?php   

                                   $sqlpro_tra = "SELECT sum(qty) FROM tranfer WHERE status = 'unapproved' AND now_branch = '$userbranch'";
                                   $results_pro = mysqli_query($conn,$sqlpro_tra);
                                   $data = mysqli_fetch_array($results_pro);
                                    $total = $data[0];
                                  
                                 ?>
                                <span class="s-48 font-weight-lighter text-primary sc-counter"><?php  echo  $total;  ?></span>
                                <div class="float-right">
                                        <!--<span class="icon icon-arrow_upward s-48"></span>-->
                                    </div>
                            </div>
                            <div class="row p-2 s-18 text-center">
                                <div class="col-6 b-r"> 
                                    <i class="icon icon-arrow_upward text-success mr-2"></i><div></div>
                                </div>
                                <div class="col-6"> 
                                        <i class="icon icon-arrow_downward text-danger mr-2"></i> <div></div>
                                </div>
                            </div>
                        </div>
                           <div class="col-md-3 shadow">
                        <div class="p-5 bg-secondary text-white">
                                <h6 class="font-weight-normal s-14 "> QUANTITY PRODUCT EXPIRED</h6>
                                <?php   

                                   $sqlpro_tra2 = "SELECT SUM(qty) AS qty_num FROM tranfer WHERE status = 'unapproved' AND now_branch = '$id'";
                                  $results_pro2 = mysqli_query($conn,$sqlpro_tra2);
                                  $num_pro_num2 = mysqli_fetch_array($results_pro2);
                                 ?>
                                <span class="s-48 font-weight-lighter text-primary sc-counter"><?php  echo  $getExpired;  ?></span>
                                <div class="float-right">
                                        <!--<span class="icon icon-arrow_upward s-48"></span>-->
                                    </div>
                            </div>
                            <div class="row p-2 s-18 text-center">
                                <div class="col-6 b-r"> 
                                    <i class="icon icon-arrow_upward text-success mr-2"></i><div></div>
                                </div>
                                <div class="col-6"> 
                                        <i class="icon icon-arrow_downward text-danger mr-2"></i> <div></div>
                                </div>
                            </div>
                        </div>
                    
                <div class="col-md-3">
                <div class="p-5 deep-purple lighten-3 text-white">
                              <h6 class="font-weight-normal s-14">
                              ALL CUSTOMER</h6> <span class="s-48 
                              font-weight-lighter text-primary sc-counter"><?php echo $customertotal;


                          ?></span>
                        <div class="float-right">
                                <!--<span class="icon icon-arrow_downward s-48"></span>-->
                            </div>
                    </div>
                    <div class="row p-2 s-18 text-center">
                        <div class="col-6 b-r"> 
                            <i class="icon icon-arrow_upward text-success mr-2"></i><div></div>
                        </div>
                        <div class="col-6"> 
                                <i class="icon icon-arrow_downward text-danger mr-2"></i> <div></div>
                        </div>
                    </div>
                </div>

        </div>

    </div>
</div>
    
<div class="row m-1 " >
<div class='col-md-6 ' style=" margin-top:15px;">
<div class='card ' style=" margin-bottom: 10px;box-shadow: 5px 5px 10px rgba(0,0,0, 0.1);">
<h3 class='card-header bg-white'> <center>ALL MORE DETAILS</center></h3>
<div class='card-body'>
<div class='table-responsive'>
<table class="table table-hover  table-bordered" style="margin-left: -10px;">
     <thead>                   
                            
          <center><tr style="font-weight:bold;color: purple;text-transform: ;">
            
                <th>Registered Branch</th>
                 <th>Total Expenses(TSH)</th>
                 <th>Total Employee</th>
             </tr>
        </thead>
            <tbody> 
             <center>
        <center><tr style="font-weight:bold;font-size: 15px;">
            
            
    <td class='sc-counter' > <?php echo $getBranchTotal;?></td>     

    <td class='sc-counter'>  <?php echo $getSumExpense;?></td>   
     <td class='sc-counter'><?php echo $getEmployeeTotal;?></td>
</tr>

                    </tbody>
                </table>
                </div>
            </div>
    </div>
</div>
<div class='col-md-6' style=" margin-top:15px;">
<div class='card' style="box-shadow: 5px 5px 10px rgba(0,0,0, 0.1);">
<h3 class='card-header bg-white'> <center>INVENTORY DETAILS</center></h3>
<div class='card-body'>
<table class="table  table-hover table-bordered">
                                
                               <thead>
                                
                                   <center><tr style="font-weight: bold;color: purple;font-size: 15px;">
                                     
                                   <th>Total purschasing</th>  
                                   <th>Transfered stock</th> </tr>
                               </center> 
                              
                                </thead>
                                <tbody>
                                 <tr>
                                 
                                 <center>
                                  
                                     <td class='sc-counter'> <?php echo $getPurschasing;?></td>

                                    <td class='sc-counter'> <?php echo $getTransfered ;?></td>



                                 </center>
                                  
                                </tr>
                               
                            </tbody>
                        </table>
                    </div>
                </div>
              </div>
            <div class="container">         
               <centre><h4 class="card-header offset-0.5 pr-2" style="color:#04600A;">PRODUCT INFORMATION TRACKING SYSTEM  VERSIONS 1.0</h4></centre>
            </div>
</div>
 <script src="assets/js/app.js"></script>
 
        </body>
        </html>
           