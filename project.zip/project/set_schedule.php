<?php
include"auth.php";
include('connect/connect.php');
$id_emlo = $_GET['id'];
if (isset($_POST['reg'])) {
$a = $_POST['day'];
$b = $_POST['week'];
$c = $_POST['contact'];
$e = $_POST['memno'];
$d = $_POST['date_sch'];

$sqlcheck = "SELECT * FROM schedule WHERE employee_id ='$id_emlo' AND day ='$a' AND week ='$b' AND mon ='$c' AND years ='$e'";

$results_check = mysqli_query($conn,$sqlcheck);

$num = mysqli_num_rows($results_check);

echo $num;


if ($num <= 0) {
     $sql = "INSERT INTO `schedule` (`id_sch`,`employee_id`,`day`, `week`, `mon`, `years`, `date_sch`) 
    VALUES (NULL, '$id_emlo','$a','$b', '$c', '$e', '$d')";
    $result = mysqli_query($conn,$sql);
    if ( $result) {
        echo "day seted";
    }
}
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php include('includes/nav.php');?>
        <div class='has-sidebar-left has-sidebar-tabs'>

                          <div class='col'>
                        <h1 class='s-2 mt-3'>
                            
                           <center><?php include('system_name.php');?></center>
                        </h1>
                    </div>
<div class='card-body'>
	<div class="jumbotron">	
	<div class="container">
		
<form action="" class="bg-light needs-validation m-3" novalidate method="post" style="border: 1px purple" >
           
            <div class="container">
            	<center>
                	<h3 class='card-header bg-white'> <center>ADD EMPLOYEE SCHEDULES DETAILS</center></h3>
                     </center>
            <div class="row ">


                <div class="col-6">
                	
                    <div class="form-group">
                <label for="validationCustom01">Day</label>
                <select name="day" class="form-control">
                    <option >Monday</option>
                    <option>Tuesday</option>
                    <option >Wednesday</option>
                    <option >Thursday</option>
                    <option >Friday</option>
                    <option >Saturday</option>
                    <option >Sunday</option>
                </select>
                <br>
                <label for="validationCustom01">Week</label>
                <select name="week" class="form-control">
                    <option>first week</option>
                    <option >second week</option>
                    <option >third week</option>
                    <option >fourth week</option>
                </select>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter address
                </div>

            </div>
          </div>
                  <div class="col-6">
                     
                    <div class="form-group">
                <label for="validationCustom01">Month</label>
                <input type="text" name="contact" id="validationCustom01" class="form-control " placeholder="Contact" aria-describedby="helpId" value="<?php echo date('m'); ?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter contact
                </div>

            </div>

                  <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Years</label>
                <input type="text" name="memno" id="validationCustom01" class="form-control" aria-describedby="helpId" readonly value="<?php echo date('Y'); ?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  Jaza Membership no
                </div>

            </div>
          </div>
            

       <div class="col">
      


          <input type="text" name="date_sch" id="validationCustom01" class="form-control" aria-describedby="helpId" readonly value="<?php echo date('d/m/Y'); ?>">
         </div>

                </div>
            </div>    
            <br>
            <hr>
            <div class="container">
            <div class="form-group">
               <center> <button class="btn btn-secondary  col-6"  name="reg" style="background-color: purple;opacity: 0.4">Submit Details</button></center>
                <div class="form-group"></div>
                <hr>
            </div>
        </div>
        </div>

</div>
</div>

            </div>
        </form>
    </div>

    </div>
</div>
</div>


<script src="assets/js/app.js"></script>
</body>
</html>
