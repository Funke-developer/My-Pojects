<?php
error_reporting(0);
include"auth.php";
include('connect/connect.php');
$id_cash = $_SESSION['cash'];
if (isset($_POST['reg'])) {
$a = htmlspecialchars($_POST['name']);
$b =  htmlspecialchars($_POST['address']);
$c =  htmlspecialchars($_POST['contact']);
$e =  htmlspecialchars($_POST['memno']);

$sql1 = "SELECT * from customer";
$results1 = mysqli_query($conn,$sql1);
$num = mysqli_num_rows($results1);

echo $num;
if ($num <= 0) {
    $d = 100;
    $sql = "INSERT INTO customer (customer_id,customer_name,address,contact,membership_number) VALUES (NULL,'$a','$b','$c','$d')";
    $result = mysqli_query($conn,$sql);

}else{

    $sql = "INSERT INTO customer (customer_name,address,contact,membership_number) VALUES ('$a','$b','$c','$e')";
    $result = mysqli_query($conn,$sql);

if ($result) {
$phone=$c;
$date=date("d-m-Y");
$msg = "Ndugu $a mteja wa supermarket yetu tunakukaribisha tena kwenye supermarket yetu  kwanzia leo tarehe $date utatumia namba ya uanachama hii hapa $e Asante";

//.... replace <api_key> and <secret_key> with the valid keys obtained from the platform, under profile>authentication information
$api_key= "ad475642d371aece";
$secret_key = "YzY0ZWQ5OTk5ZWFmOWE4MmZkNmYxNTY0MWViZGExYTZjMDE5MTkzMGIwN2VkMzY0Y2M4MWNiMTZhZDYwMzYyMg==";
// The data to send to the API
$postData = array(
    'source_addr' => 'INFO',
    'encoding'=>0,
    'schedule_time' => '',
    'message' => $msg,
    'recipients' => [array('recipient_id' => '2','dest_addr'=>$phone)]
);
//.... Api url
$Url ='https://apisms.bongolive.africa/v1/send';

// Setup cURL
$ch = curl_init($Url);
error_reporting(E_ALL);
ini_set('display_errors', 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt_array($ch, array(
    CURLOPT_POST => TRUE,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_HTTPHEADER => array(
        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
        'Content-Type: application/json'
    ),
    CURLOPT_POSTFIELDS => json_encode($postData)
));

// Send the request
$response = curl_exec($ch);

// Check for errors
if($response === FALSE){
        //echo $response;
    echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Network Error API failed'
    data-type='danger'>
    </div>";
  header("location:manage_customer.php?not-sent=warning");
    //die(curl_error($ch));
}
  else{ echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Successfully Added'
    data-type='success'>
    </div>";
    header("location:manage_customer.php?added=success");}

    }
}
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <script src="assets/js/app.js"></script>
    <?php 

    if ($id_cash =='cashier') {
       include 'includes/cashiernav.php'; 
    }else{
        include 'includes/nav.php'; 
    }
    ?>
<div class='has-sidebar-left has-sidebar-tabs'>
 <div class='col'>
    <h1 class='s-2 mt-3'> <center>
        <?php include('system_name.php');?>
             </center>
         </h1></div>
         <div class='card-body'>
            <div class="jumbotron">	
                <div class="container">
                <form action="" class="bg-light needs-validation m-3" novalidate method="post" style="border: 1px purple" >
            <div class="container">
            	<center>
                	<h3 class='card-header bg-white'>
                        <center>ADD NEW CUSTOMERS DETAILS</center>
                    </h3>
                     </center>
                     <div class="row "><div class="col-6">
                    <div class="form-group"><label for="validationCustom01">Full name</label>
                        <input type="text" id="validationCustom01" class="form-control " placeholder="Fullname" aria-describedby="helpId"  name="name" pattern="[Aa-Zz]" title="Ony letter for  customer name" autofocus="on"><br>
                          <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter fullname
                </div>
                <label for="validationCustom01">Address</label>
                <input type="text" name="address" id="validationCustom01" class="form-control " placeholder="Address" aria-describedby="helpId" required value="">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter address
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <label for="validationCustom01">Contact</label>
                <input type="number" name="contact" id="" class="form-control" placeholder="255XXXXXXXX" aria-describedby="helpId" required pattern="" maxlength="12" title="Enter phone number">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter contact
                </div>

            </div>

                  <div class="form-group">

                <label for="validationCustom01">Membership no</label>
                <?php 

                $sql2 = "SELECT * from customer order by membership_number desc limit 1";
                 $results2 = mysqli_query($conn,$sql2);
                $fecth2 = mysqli_fetch_array($results2);
                $id_member = $fecth2['membership_number'];

                   $member = $id_member + 1;

                 ?>
                <input type="text" name="memno" id="validationCustom01" class="form-control" aria-describedby="helpId" readonly value="<?php echo $member; ?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter Membership no
                </div>
            </div>
          </div>
       <div class="col">  
       </div>
   </div>
</div>
<br>
<hr>
<div class="container">
<div class="form-group">
                <center>
                    <button class="btn btn-secondary  col-md-6"  name="reg" style="background-color: purple;opacity: 0.4">Submit Details</button>
                    <div class="form-group"></div></center>
                </div>
                <hr>
            </div>
            <hr>
            </div>
        </div>
    </div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
<center><?php include("footer.php");?></center>
</body>
</html>
