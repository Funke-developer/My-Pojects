<?php 

include('connect/connect.php');
	$id=$_GET['id'];
	$sql ="DELETE FROM branch WHERE id='$id'";
	$result=mysqli_query($conn,$sql);
	header("location:branch.manage.php");

?>