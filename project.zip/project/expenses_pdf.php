<?php
include"auth.php";
include('model/db_connection.php');
include('model/userModel.php');
require('fpdf/fpdf/fpdf.php');
include('connect/connect.php');
$total=new userModel();
$getSumExpense=$total->getSumExpense();
$pdf = new FPDF();
$pdf->AddPage('l','A4','mm');

// $pdf->Cell(40,10,'Helgygcduycgudygcvyugfvyu',1,0,1,'C');
$pdf->SetFont('Arial','',10);
// Move to 8 cm to the right
$pdf->SetFont('Arial','B',20);
$pdf->SetTextColor(0,0,0);
// Centered text in a framed 20*10 mm cell and line break
// $pdf->Image('image/download1.png',10,10,-300); 

$pdf->Cell(260,10,'',0,1,'C');
$pdf->Cell(260,30,'PRODUCT INFORMATION TRACKING SYSTEM',0,1,'C');


$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,0,0);
// Centered text in a framed 20*10 mm cell and line break
$pdf->Cell(260,10,'ALL EXPENSES REPORTS',0,1,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,10,'No',1,0,'C');
$pdf->Cell(60,10,'EXPENSES NAME',1,0,'C');
//$pdf->Cell(60,10,'FULLNAME',1,0,'C');
$pdf->Cell(60,10,'BRANCH NAME  ',1,0,'C');

$pdf->Cell(60,10,'AMOUNT ',1,0,'C');
$pdf->Cell(65,10,'DATE',1,1,'C');
$tarehe= date('d-m-Y');

$select="SELECT * FROM expense join branch where expense.brnch_id=branch.id order by `date` desc";
$res=mysqli_query($conn,$select);
$x=1;
while($row = mysqli_fetch_array($res)){
$pdf->SetFont('Arial','',10);
$pdf->Cell(20,10,$x,1,0,'C');
$pdf->Cell(60,10,$row['expense_name'],1,0,'C');
//$pdf->Cell(60,10,$row['fullname'],1,0,'C');
$pdf->Cell(60,10,$row['branch_name'],1,0,'R');
$pdf->Cell(60,10,$row['amount'],1,0,'R');

$pdf->Cell(65,10,$row['date'],1,1,'R');



  

    
    
    
$x++;
}

$pdf->Cell(265,10,'ALL EXPENSES TOTAL  IS    ' .$getSumExpense.'',1,1,'L');

$pdf->Cell(70,20,'',0,1,'C');
$pdf->SetFont('Arial','',17);

$pdf->Cell(200,10,'Report on date: '.date('l-d-m-y'),0,1);

$pdf->Output();

?>