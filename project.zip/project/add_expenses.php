<?php 
error_reporting(0);
include 'auth.php';
include 'model/db_connection.php';
include 'model/userModel.php';
include('connect/connect.php');
$id_cash = $_SESSION['cash'];
if (isset($_POST['reg'])) {
$a = $_POST['expense_name'];
$b = $_POST['branch_name'];
$c = $_POST['amount'];
$d = $_POST['date'];
$e = $_POST['note'];
$sql="INSERT INTO `expense` (`expense_name`, `brnch_id`, `amount`, `date`, `note`, `id_expenses`) VALUES ('$a',
'$b','$c','$d','$e',NULL)";
$result=mysqli_query($conn,$sql);
header("location:list_expense.php?text='success'");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="../assets/img/basic/favicon.ico" type="image/x-icon">
   <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">               
     <?php 

    if ($id_cash =='cashier') {
       include 'includes/cashiernav.php'; 
    }else{
        include 'includes/nav.php'; 
    }
    

    ?> 
    <div class='has-sidebar-left has-sidebar-tabs'>
        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
             <div class='card my-3 no-b'>
                 <div class='card-body ' >
                        <div style="height: 20px;"></div>
                         <center><h4 class="card-header">ADD NEW EXPENSES HERE</h4></center><br>
                        <div style="height: 30px;"></div>
                    <form method="POST" action="">
                        <div class="row">    
                        <div class="form-group col-md-5">
                           <input type="text" name="expense_name" required="" placeholder="Enter Expense Name" class="form-control">
                            </select>
                        </div>
                        <div class="form-group col-md-5">
                         <select class="form-control" id="" name="branch_name">
                                <option class="form-control" selected disabled>select Branch</option>
                                 <?php

                              $user = new userModel();
                              $datauser = $user->getBranch();
                              foreach ($datauser as $value) {
                                echo"
                                <option class='form-control' value=".$value['id'].">".$value['branch_name']."</option>";
                                }?>

                

                            </select>
                        </div>                       
                        </div>
                        <div class="row">
                         <div class="form-group col-md-5">
                            
                               <input type="number" name="amount" placeholder="Enter amount" class="form-control">
                            </select>
                        </div>                      
                       
                        
                        <div class="form-group col-md-5" id='selected_area'>
                            <input type="date" name="date" placeholder="Enter date" class="form-control">
                            
                        </div>
                        </div>
                        <div class="row">

                        <div class="form-group col-md-5">  
                            <input type="text" name="note" class="form-control" placeholder=" Any note">
                        </div>
                        <div class="form-group col-md-5">
                            <input type="submit" name="reg" class="btn btn-success" value="Add Expense Details" >
                        </div>
                         </div>  
                    </form>
                 </div>
            </div>
        </div>
    </div>  
</body>
<script src="assets/js/app.js"></script>


</html>