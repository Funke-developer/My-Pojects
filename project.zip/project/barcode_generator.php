<?php
error_reporting(0);
include 'auth.php';
include 'model/db_connection.php';
include 'model/userModel.php';
$id_cash = $_SESSION['cash'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
   <?php 

    if ($id_cash =='invetory') {
       include("includes/inventorynav.php");
    }else{
        include 'includes/nav.php'; 
    }
  
    ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            
                           <center><?php include('system_name.php');?></center>
                        </h1>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
             <div class='card my-3 no-b'>
                 <div class='card-body'>
                    <div class="table-responsive">
                        <center>
                  <h3 class='card-header bg-white'> <center>AUTOMATICS BAR CODE GENERATOR FOR PRODUCT</center></h3>
                     </center>
                        <table id="example2" class="table table-bordered table-hover data-tables"
                               data-options='{ "paging": false; "searching":false}'>
                              
                            <thead>
                           <tr>
                               <th>S/N</th>
                                <th>Product Code</th>
                                <th>Product name</th>
                                <th>Purschasing Price</th>
                                <th>Selling Price</th>
                                <th>Quantity</th>
                                
                               <th>Barcode Generator</th>
                              
                            </tr>
                            </thead>
                            <tbody>
                                 <?php

                              $user = new userModel();
                              $datauser = $user->getProduct();

                              $x = 1;
                              foreach ($datauser as $value) {
                                
                               ?>

                                <tr>
                                  <td><?php echo $x ?></td>
                                  <td><?php echo $value['product_code']; ?></td>
                                  <td><?php echo $value['prod_name']; ?></td>
                                  <td><?php echo $value['purscasing_price']; ?></td>
                                   <td><?php echo $value['selling_price']; ?></td>
                                  <td><?php echo $value['quantinty']; ?></td>
                                  <?php $code_barcode=$value['product_code'];?>
                                   <td><a href="generator.php?text=<?php echo $code_barcode;?>&&amount=<?php echo $value['quantinty'];?>" class="btn btn-info">Click To Generate barcode</a></td>
                                 
                                </tr>
                          <?php

                            $x++;

                           }

                           ?>
                            </tbody>
                            <tfoot>
                             <tr>
                               <th>S/N</th>
                                <th>Product Code</th>
                                
                                <th>Product name</th>
                             
                                <th>Purschasing Price</th>
                                <th>Selling Price</th>
                                <th>Quantity</th>
                                
                                <th>Barcode Generator</th>
                               
                            </tr>
                            </tfoot>
                        </table>
                        </div>

                 </div>
            </div>
        </div>
    </div> 
</body>
<script src="assets/js/app.js"></script>
</html>