<?php
include('connect/connect.php');
	$id = $_GET['id'];
	$sql ="DELETE FROM expense WHERE id_expenses='$id'";
	$result=mysqli_query($conn,$sql);
	header("location:expenses_manage.php");

?>