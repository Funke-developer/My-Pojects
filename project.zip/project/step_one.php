<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>SOKOINE UNIVERSITY OF AGRICULTURE  STAFF  INFORMATION  SYSTEM</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class=" " style="background-color:;">
<div id="app">
        <div class="card-body">
<main>
    <div id="primary" class="p-t-b-40 height ">
        <div class="container " >
            <div class="row">
                <div class="col-12 paper-card ">
                    <div class="text-center mb-4">
                         <center>
                            <h4 class="card-header" style="color: #04600A;">
                                 
                          SECTION 1:  PERSONAL INFORMATION
                    
                            </h4><br>
                        <p>        
                        </p>
                    </div>
                    <form action="" method="POST">
  <div class="form-row">
    <div class="form-group col-md-5">
      <label for="inputEmail4">Present Station</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Faculty/Directorate/ Institute/  Department/Section"required>
    </div>
    <div class="form-group col-md-5">
      <label for="inputPassword4">Name in Full</label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="Surname/First name/Middle name" required="on">
    </div>
    <div class="form-group col-md-2">
      <label for="inputState">Gender</label>
      <select id="inputState" class="form-control" required="on">
        <option selected>Choose...</option>
        <option>MALE</option>
        <option>FEMALE</option>
      </select>
    </div>
</div>
  <div class="form-row">
  <div class="form-group col-md-4">
    <label for="inputAddress">Academic Qualification</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="Academic Qualification" required="on">
  </div>

    <div class="form-group col-md-4">
      <label for="inputEmail4">Duty Post</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Duty Post" required="on">
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4">Substantive Post</label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="  Substantive Post" required="on">
    </div>
</div>
  
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputCity">Date of First Appointmen</label>
      <input type="date" class="form-control" id="inputCity" required="on">
    </div>
    
    <div class="form-group col-md-4">
      <label for="inputZip">Date of Appointment to present post</label>
      <input type="date" class="form-control" id="inputZip" required="on">
    </div>
    <div class="form-group col-md-4">
      <label for="inputZip">Date of birth</label>
      <input type="date" class="form-control" id="" required="on">
    </div>


  </div>
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputCity">Salary Scale</label>
      <input type="text" class="form-control" id="inputCity" placeholder="Salary Scale" required="on">
    </div>
    
    <div class="form-group col-md-4">
      <label for="inputZip">Period served under Present Supervisor</label>
      <input type="number" class="form-control" id="inputZip" placeholder="Period served under Present Supervisor" required="on">
    </div>
    <div class="form-group col-md-4">
      <label for="inputZip">Terms of Service</label>
      <input type="text" class="form-control" id="" placeholder="Terms of Service" required="on">
    </div>



  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck" required="on">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <br>
  <br>
  <div class="container">
<center><button type="submit" name="submit" class="btn btn-success col-md-6 text-white" style="border: 1px solid white;opacity: 0.6;">Submit Personal Information</button></center></div>
                        <p></p>
                </div>
            </form>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</div>
</div>
<script src="assets/js/app.js">
</script>
</body>
</html>