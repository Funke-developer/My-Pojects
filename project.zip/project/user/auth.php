<?php
session_start();
if(!isset($_SESSION['email'])){
    header("location:../index.php");
}else{
    
   
//	echo "<meta http-equiv='refresh' content='360;URL=logout.php'>";	 
    
    

}
?>