<?php
$id=$_GET['id'];
include 'auth.php';
include('connect/connect.php');
include 'model/db_connection.php';
include 'model/userModel.php';
$select="SELECT * FROM customer WHERE customer_id='$id'";
$result = mysqli_query($conn,$select);
$fetch=mysqli_fetch_array($result);
if (isset($_POST['reg'])) {
$a = $_POST['name'];
$b = $_POST['address'];
$c = $_POST['contact'];
$d = $_POST['memno'];
$e = $_POST['prod_name'];
$f = $_POST['note'];
$g = $_POST['date'];
$sql ="UPDATE `customer` SET `customer_name` = '$a', `address` = '$b', `contact` = '$c', `membership_number` = '$d', `prod_name` = '$e', `expected_date` = '$f', `note` = '$g' WHERE `customer`.`customer_id` = '$id'";
$result = mysqli_query($conn,$sql);
if ($result) {
	 echo"<script>alert('New customer Updated Successfully')</script>";
}
header("location:manage_customer.php?msg='text'");

}

  
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>

                          <div class='col'>
                        <h1 class='s-2 mt-3'>
                            
                           <center><?php include('system_name.php');?></center>
                        </h1>
                    </div>
<div class='card-body'>
	<div class="jumbotron">	
	<div class="container">
		
<form action="" class="bg-light needs-validation m-3" novalidate method="post" style="border: 1px purple" >
           
            <div class="container">
            	<center>
                	<h3 class='card-header bg-white'> <center>UPDATE CUSTOMERS DETAILS</center></h3>
                     </center>
            <div class="row ">


                <div class="col-6">
                	
                    <div class="form-group">
                <label for="validationCustom01">Full name</label>
                <input type="text" id="validationCustom01" class="form-control " placeholder="Fullname" aria-describedby="helpId" required name="name" value="<?php echo $fetch['customer_name']?>">
                <br>
                <label for="validationCustom01">Address</label>
                <input type="text" name="address" id="validationCustom01" class="form-control " placeholder="Address" aria-describedby="helpId" required value="<?php echo $fetch['address'];?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter address
                </div>

            </div>
          </div>
          
                  <div class="col-6">
                     
                    <div class="form-group">
                <label for="validationCustom01">Contact</label>
                <input type="text" name="contact" id="validationCustom01" class="form-control " placeholder="Contact" aria-describedby="helpId" required value="<?php echo $fetch['contact'];?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter contact
                </div>

            </div>
          </div>
            </div>

            <div class="row ">
                 <div class="col">
                     <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Product name Buying Frequently</label>
                <input type="text" name="prod_name" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required value="<?php echo $fetch['prod_name'];?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter product name
                </div>

            </div>

                </div>
                 <div class="col">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Membership no</label>
                <input type="text" name="memno" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required value="<?php echo $fetch['membership_number'];?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  Jaza Membership no
                </div>

            </div>


                </div>
            </div>
             <div class="row ">

                <div class="col-6">
                   
                    <div class="form-group">
                      
                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Date</label>
                <input type="text" name="date"  id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required  value="<?php echo $fetch['expected_date'];?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter date
                </div>

            </div>
          </div>
                
        
                 <div class="col">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Note</label>
                <input type="text" name="note" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required value="<?php echo $fetch['note'];?>">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter note
                </div>

            </div>

                </div>
               
            </div>
            
        
            <br>
            <hr>
            <div class="form-group">
                <button class="btn btn-secondary  col"  name="reg" style="background-color: purple;opacity: 0.4">Submit Details</button>
                <div class="form-group"></div>
                <hr>
                
               
                
</div>
</div>

            </div>
        </form>
    </div>

    </div>
</div>

<script src="assets/js/app.js"></script>
</body>
</html>
