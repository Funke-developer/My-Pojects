<?php 
class userModel extends db_connection{
	public function loginInfo($email,$password){
		$sql = "SELECT * FROM user WHERE username= '$email'  and password ='$password'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		return $data;
	}
	public function getCustomer(){
		$sql = "SELECT * FROM customer order by customer_name asc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}
		public function getBranch(){
		$sql = "SELECT * FROM `branch` order by branch_name asc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}

	public function getProduct(){
		$sql = "SELECT * FROM products";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}
	
public function delAlluser($username){
		$sql_admin="DELETE FROM `user` WHERE username='$username' ";
		$results__get = mysqli_query($this->connection(),$sql_admin);
		$sql_applicant_all = mysqli_fetch_all($results__get,MYSQLI_ASSOC);
		return $sql_applicant_all;
	}
	
		
		public function getUser(){
		$sql = "SELECT * FROM user join branch where user.branch_id=branch.id";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}

	public function getlog(){
		$sql = "SELECT * FROM userlog order by stamp desc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}


	public function getCustomerToedit($id){
$sql="SELECT * FROM customer WHERE customer_id='$id'";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}


		public function getSumProduct(){
	    
		$sql="SELECT SUM(qty_sold) FROM product";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
public function getEmployeeTotal(){
		$sql = "SELECT * FROM user";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}

public function getCustomerTotal(){
		$sql = "SELECT * FROM customer";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}
	public function getProductTotal(){
		$sql = "SELECT * FROM products";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}
	public function getBranchTotal(){
		$sql = "SELECT * FROM branch";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}
	public function getNum(){
		$sql = "SELECT jengo FROM agano";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}
	public function getNumAhadi(){
		$sql = "SELECT ahadi FROM agano";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}

	
	public function getNumtotal(){
	    
		$sql="SELECT SUM(jengo) FROM matoleo";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	
	
		public function getNumtotalahadiToday1($date,$time){
		$sql="SELECT SUM(ahadi) FROM matoleo WHERE tarehe ='$date' AND time='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getNumtotaljengoToday1($date,$time){
		$sql="SELECT SUM(jengo) FROM matoleo WHERE tarehe ='$date' AND time='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getNumtotalahadiToday($date){
		$sql="SELECT SUM(ahadi) FROM matoleo WHERE tarehe ='$date'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getNumtotaljengoToday($date){
		$sql="SELECT SUM(jengo) FROM matoleo WHERE tarehe ='$date'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getViongoziAhadizote(){
        $sql="SELECT * FROM `agano` join orodha_kuu on 
        agano.bahasha_namba = orodha_kuu.id ORDER BY `hali` ASC ";
        $result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}

		return $arrayData;
	}
	
		public function updateWauminichange($id,$fullname,$jinsia,$date,$mahali,$ndoa,$simu,$mtaa,$makazi,$nyumba,$kazi,$elimu,$taaluma){
			$sql="UPDATE `orodha_kuu` SET `id` = '$id', `jina` = '$fullname', `jinsia` = '$jinsia', `Dob` = '$date', `mahali` = '$mahali', `ndoa` = '$ndoa', `simu` = '$simu', `mtaa` = '$mtaa', `makazi` = '$makazi', `nyumba_Na` = '$nyumba', `kazi` = '$kazi', `elimu` = '$elimu', `taaluma` = '$taaluma' WHERE `orodha_kuu`.`id` = '$id'";
		$result = mysqli_query($this->connection(),$sql);
		return $result;
	}
	
		public function getsummitaa($date,$time){
		$sql="SELECT SUM(sad_za_mitaa ) FROM matoleo WHERE tarehe ='$date' AND ibada='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getsumjumuia($date,$time){
		$sql="SELECT SUM(sad_za_jumuiya) FROM matoleo WHERE tarehe ='$date' AND ibada='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	
	
	
	public function getWauminipdfhusika($date1){

$sql="SELECT * FROM matoleo WHERE matoleo.tarehe ='$date1' order by tarehe desc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}
		public function getsumschool($date,$time){
		$sql="SELECT SUM(sunday_school) FROM matoleo WHERE tarehe ='$date' AND ibada='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
}
?>