<?php 

include('connect/connect.php');
	$id=$_GET['id'];
	$sql ="DELETE FROM customer WHERE customer_id='$id'";
	$result=mysqli_query($conn,$sql);
	header("location:manage_customer.php");

?>