<?php
include 'auth.php';
include('connect/connect.php');
include 'model/db_connection.php';
include 'model/userModel.php';
if (isset($_POST['Register'])) {
 //take inputs from the users
    $branch=$_POST['branch'];
    $sql="INSERT INTO `branch` (`id`, `branch_name`) VALUES (NULL, '$branch')";
    $result=mysqli_query($conn,$sql);
    if ($result) {
        # code...


    }
}


?>
<!DOCTYPE html>
<html>
<head>
  <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
  <link rel="stylesheet" href="assets/css/app.css">  
     <style>
        form {

            margin: 50px auto;
            width: 900px;
            padding: 20px;
            box-shadow: 0px 0px 16px rgba(0, 0, 0, 0.6);

        }
        body{
          
        }
        .btn-pink{
          /*background-color: #c1739b;*/
          color: white;
        }
         .btn-pink:hover{
            /*background-color: #cf99a5;*/
            color: white;

        }
        .errors{
            color: red;
        }
    </style>
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
    
    <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>
                </div>
            </div>
            <div class="jumbotron"> 
    <div class="container">
        <form action="" class="bg-light needs-validation" novalidate method="post">
            <center><h4 class="card-header">ADD BRANCH HERE</h4></center><br>
           
            <div class="row ">
                <div class="col-6">
                    <div class="form-group">
                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01"></label>
                <input id = "" type="text" id="validationCustom01" class="form-control" 
                name="branch" placeholder="Enter Branch Name" aria-describedby="helpId" required value="" >
            
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    Enter branch name
                </div>
            </div>
          </div>
        <div class="col-6">
            <div class="form-group">
                <button class="btn btn-secondary" 
                name="Register" style="background-color: purple;">
            Submit Here
        </button>
    </div>
            <div class="form-group"></div>
            </div>
            <div class="form-group"></div>
            
                <div class="form-group"></div>

            <p style="margin-top: 35px"></p>
            <p></p>
            </div>
                <hr>
                    
            </div>
             </div>
        </form>
        </div>
</body>
<script>  
// Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
</script>
<script src="node_modules/jquery.js"></script>
<!-- <script src="https://unpkg.com/@popperjs/core@2"></script> -->
<script src="node_modules/@popperjs/core"></script>
<script src="assets/js/app.js"></script>

<script src="node_modules/bootstrap/js/bootstrap.js"></script>
</html>


