<?php
session_start();
include('connect/connect.php');
if (isset($_POST['reg'])) {
$a = $_POST['code'];
$b = $_POST['name'];
$c = $_POST['exdate'];
$d = $_POST['price'];
$e = $_POST['supplier'];
$f = $_POST['qty'];
$g = $_POST['o_price'];
$h = $_POST['profit'];
$i = $_POST['gen'];
$j = $_POST['date_arrival'];
$k = $_POST['qty_sold'];
// query
$sql = "INSERT INTO products (product_code,product_name,expiry_date,price,supplier,qty,o_price,profit,gen_name,date_arrival,qty_sold) VALUES ('$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k')";
$result = mysqli_query($conn,$sql);
if ($result) {
     echo"<div class='toast bg-brown'
    data-title='Authentification Centre'
    data-message='New customer Added Successfully'
    data-type='success'> 
    </div>";

header("location: product.php");
}
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>

<h3 class='card-header bg-white'> <center>ADD NEW PRODUCTS DETAILS</center></h3>
<div class='card-body'>
	<div class="jumbotron">	
	<div class="container">
		
<form action="" class="bg-light needs-validation m-3" novalidate method="post" style="border: 1px purple" >
           
            <div class="container">
            	<center>
                	<h3 class='card-header bg-white'> <center>ADD NEW PRODUCTS DETAILS</center></h3>
                     </center>
            <div class="row ">


                <div class="col-6">
                	
                    <div class="form-group">
                <label for="validationCustom01">Code name</label>
                <input type="text" id="validationCustom01" class="form-control " placeholder="Code name" aria-describedby="helpId" required name="code">
                <br>
                <label for="validationCustom01">Expire Date</label>
                <input type="date" name="exdate" id="validationCustom01" class="form-control " placeholder="Expire date" aria-describedby="helpId" required value="">
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter date
                </div>

            </div>
          </div>
          
                  <div class="col-6">
                     
                    <div class="form-group">
                <label for="validationCustom01">Product Name</label>
                <input type="text" name="name" id="validationCustom01" class="form-control " placeholder="Product Name" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter name
                </div>

            </div>
          </div>
            </div>

            <div class="row ">
                 <div class="col">
                     <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Price</label>
                <input type="text" name="supplier" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required >
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter product suppliers
                </div>

            </div>

                </div>
                 <div class="col">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Total Quanty</label>
                <input type="text" name="qty" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  Jaza total
                </div>

            </div>


                </div>
            </div>
             <div class="row ">

                <div class="col-6">
                   
                    <div class="form-group">
                      
                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Date</label>
                <input type="date" name="date_arrival"  id="validationCustom01" class="form-control " placeholder="Date of arrival" aria-describedby="helpId" required >
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter date
                </div>

            </div>
          </div>
                
               
        
                 <div class="col">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Profit</label>
                <input type="text" name="profit" id="validationCustom01" class="form-control " placeholder="profit" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter profit
                </div>

            </div>



               
            </div>
            
        
            <br>
            <hr>
           
  <div class="row ">

                <div class="col-4">
                   
                    <div class="form-group">
                      
                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Date</label>
                <input type="date" name="date_arrival"  id="validationCustom01" class="form-control " placeholder="Date of arrival" aria-describedby="helpId" required >
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter date
                </div>

            </div>
          </div>
                
               <div class="col-4">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Generic name</label>
                <input type="text" name="gen" id="validationCustom01" class="form-control " placeholder="Generic Name" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter generic name
                </div>

            </div>

                </div>
        
                 <div class="col-4">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Profit</label>
                <input type="text" name="profit" id="validationCustom01" class="form-control " placeholder="profit" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter profit
                </div>

            </div>



               
            </div>
            
         <div class="col-4">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Profit</label>
                <input type="text" name="profit" id="validationCustom01" class="form-control " placeholder="profit" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter profit
                </div>

            </div>



               
            </div>
            <br>
            <hr>
        
</div>


</div>
    <div class="form-group">
                <button class="btn btn-secondary  col"  name="reg" style="background-color: purple;opacity: 0.4">Submit Details</button>
                <div class="form-group"></div>
                <hr>
                
               
                
</div>
            </div>
        </form>
    </div>

    </div>
</div>

<script src="assets/js/app.js"></script>
</body>
</html>
