<?php
include 'auth.php';
include 'model/db_connection.php';
include 'model/userModel.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
  <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
             <div class='card my-3 no-b'>
                
                 <div class='card-body'>
                    <div class="table-responsive">
                        <center><h4 class="card-header">MANAGE YOUR EMPLOYEE HERE</h4></center><br>
                        <table id="example2" class="table table-bordered table-hover data-tables"
                               data-options='{ "paging": false; "searching":false}'>
                              
                            <thead>
                               <tr>
                               <th>S/N</th>
                                <th>Employee name</th>
                                     <th>Position</th>
                                     <th>Name</th>
                                     <th>Branch Name</th>
                                <th>Delete</th>
                                <th>Edit</th>
                            </tr>
                            </thead>
                            <tbody>
                                  <?php

                              $user = new userModel();
                              $datauser = $user->getUser();

                              $x = 1;
                              foreach ($datauser as $value) {
                                
                               ?>

                                <tr>
                                  <td><?php echo $x ?></td>
                                  <td><?php echo $value['username']; ?></td>

                                  <td><?php echo $value['name']; ?></td>
                                   <td><?php echo $value['position']; ?></td>
                                    <td><?php echo $value['branch_name']; ?></td>
                                   <td><a href="#"  id="<?php echo $value['id']; ?>" class="delbutton">
                                   <i class="icon icon-trash s-24 text-danger"></i>
                                 Click To Delete</a></td>
                                    <td><a href="employee_edit.php?id=<?php echo $value['id']; ?>" class="">
                                      <i class="icon icon-edit s-24 text-primary"></i>Click To Edit</a></td>
                                </tr>
                          <?php

                            $x++;

                           }

                           ?>

                              
                        
                            </tbody>
                            <tfoot>
                                 <tr>
                               <th>S/N</th>
                                <th>Employee name</th>
                                     <th>Position</th>
                                     <th>Name</th>
                                     <th>Branch Name</th>
                                <th>Delete</th>
                                <th>Edit</th>
                            </tr>
                            </tfoot>
                        </table>
                        </div>

                 </div>
            </div>
        </div>
    </div> 
</body>
<script src="assets/js/app.js"></script>
 <script type="text/javascript">
$(function() {


$(".delbutton").click(function(){

//Save the link in a variable called element
var element = $(this);

//Find the id of the link that was clicked
var del_id = element.attr("id");

//Built a url to send
var info = 'id=' + del_id;
 if(confirm("Are you sure want to delete? There is NO undo!"))
      {

 $.ajax({
   type: "GET",
   url: "employee_delete.php",
   data: info,
   success: function(){
   
   }
 });
         $(this).parents(".record").animate({ backgroundColor: "#fbc7c7" }, "fast")
    .animate({ opacity: "hide" }, "slow");

 }

return false;

});

});
</script>

</html>