<?php
include 'auth.php';
include 'model/db_connection.php';
include 'model/userModel.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                       <div class='col'>
                        <h1 class='s-2 mt-2'>
                            
                           <center><?php include('system_name.php');?></center>
                        </h1>
                    </div>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
             <div class='card my-3 no-b'>
                 <div class='card-body'>
                    <div class="table-responsive">
                      <center><h4 class="card-header">CUSTOMER BONUS MANAGEMENT</h4></center><br>
                        <table id="example2" class="table table-bordered table-hover data-tables"
                               data-options='{ "paging": false; "searching":false}'>
                              
                            <thead>
                            <tr>
                               <th>S/N</th>
                                <th>Customer Name</th>
                                <th>Adress</th>
                                <th>Contact</th>
                                <th>mambership number</th>

                                <th>Bonus</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                                  <?php

                              $user = new userModel();
                              $datauser = $user->getCustomer();

                              $x = 1;
                              foreach ($datauser as $value) {
                                
                               ?>

                                <tr>
                                  <td><?php echo $x ?></td>
                                  <td><?php echo $value['customer_name']; ?></td>
                                  <td><?php echo $value['address']; ?></td>

                                  <td><?php echo $value['contact']; ?></td>
                                  <td><?php echo $value['membership_number']; ?></td>
                            
                                   <td><a href="message.php?phone=<?php echo $value['contact']; ?>&&name=<?php echo $value['customer_name']; ?>" class="btn btn-success">Send Bonus Message</a></td>
                                    
                                </tr>
                          <?php

                            $x++;

                           }

                           ?>

                              

                              
                        
                            </tbody>
                            <tfoot>
                            <tr>
                               <th>S/N</th>
                                <th>Customer Name</th>
                                <th>Adress</th>
                                <th>Contact</th>
                                <th>mambership number</th>

                                <th>Bonus</th>
                                
                            </tr>
                            </tfoot>
                        </table>
                        </div>

                 </div>
            </div>
        </div>
    </div> 
</body>
<script src="assets/js/app.js"></script>
</html>