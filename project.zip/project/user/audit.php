<?php
include 'auth.php';
include 'model/db_connection.php';
include 'model/userModel.php';


?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/app.css">
    <style>
        .diproper{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            
            z-index: 1;
            height: 100vh;
            background-color: rgba(0,0,0, 0.6);
        }
    </style>
</head>
<body class="light sidebar-mini sidebar-collapse">
  <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
          <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>

               <div class="card my-3 no-b m-3" >
                    <div class="card-body">
                        <div class="table-responsive">
                           <center><h4 class="card-header">LOGS INFORMATIONS</h4></center><br>
                        <table id="example2" class="table table-bordered table-hover data-tables "
                               data-options='{ "paging": false; "searching":false}'>
                            <thead>
                        <tr> 
                          <th>#ID</th>
                            <th>POSITION</th>
                           
                            <th>DATE OF LOGIN </th>
                            
                            <th>IP ADRESS</th>
                            <th>TIME OF LOGIN</th>
                            <th>ACTION</th>
                     
                        </tr>
                        </thead>
                           
                        <tbody>
                          <?php

                              $user = new userModel();
                              $datauser = $user->getlog();

                              $x = 1;
                              foreach ($datauser as $value) {
                                $date1=$value['stamp'];
                               $date = date("d-m-Y", strtotime($date1)); 

                               ?>

                                <tr>
                                  <td><?php echo $x ?></td>
                                  <td><?php echo $value['position']; ?></td>
                                  <td><?php echo $date ; ?></td>
                                  <td><?php echo $value['ip']; ?></td>
                                 
                                  <td><?php echo $value['stamp']; ?></td>
                                  <td><?php echo $value['action']; ?></td>
                         
                                
                                  
                              

                          <?php

                            $x++;

                           }

                           ?>
                        </tr>
                    </tbody>
                            <tfoot>
                          
                         <tr> 
                          <th>#ID</th>
                            <th>POSITION</th>
                           
                            <th>DATE OF LOGIN </th>
                            
                            <th>IP ADRESS</th>
                            <th>TIME OF LOGIN</th>
                            <th>ACTION</th>
                     
                        </tr>
                            </tfoot>
                        </table>
                    </div>
                  </center>
                </div>
              </div>
            </div>

                </div>
                <script src="assets/js/app.js"></script>
            </body>
            </html>
