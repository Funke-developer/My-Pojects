<?php 
error_reporting(0);
$phone=$_GET['phone'];
$name=$_GET['name'];
if (isset($_POST['send'])) {
  # code...
$phone=$_GET['phone'];
$name=$_GET['name'];
$msg = $_POST['text'];

//.... replace <api_key> and <secret_key> with the valid keys obtained from the platform, under profile>authentication information
$api_key= "ad475642d371aece";
$secret_key = "YzY0ZWQ5OTk5ZWFmOWE4MmZkNmYxNTY0MWViZGExYTZjMDE5MTkzMGIwN2VkMzY0Y2M4MWNiMTZhZDYwMzYyMg==";
// The data to send to the API
$postData = array(
    'source_addr' => 'INFO',
    'encoding'=>0,
    'schedule_time' => '',
    'message' => $msg,
    'recipients' => [array('recipient_id' => '2','dest_addr'=>$phone)]
);
//.... Api url
$Url ='https://apisms.bongolive.africa/v1/send';

// Setup cURL
$ch = curl_init($Url);
error_reporting(E_ALL);
ini_set('display_errors', 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt_array($ch, array(
    CURLOPT_POST => TRUE,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_HTTPHEADER => array(
        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
        'Content-Type: application/json'
    ),
    CURLOPT_POSTFIELDS => json_encode($postData)
));

// Send the request
$response = curl_exec($ch);

// Check for errors
if($response === FALSE){
        //echo $response;
echo"<div class='toast bg-brown'
    data-title='Authentification Centre'
    data-message='New Bonus Are Not Successfully Send To customer with phone number $phone'
    data-type='errors'> 
    </div>";
    die(curl_error($ch));
}

echo"<div class='toast bg-brown'
    data-title='Authentification Centre'
    data-message='New Bonus Are Successfully Send To customer with phone number $phone'
    data-type='success'> 
    </div>";
//var_dump($response);


}
?>



?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>

                           <script src="assets/js/app.js">
  
                             </script>
                      <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>
<div class='card-body'>
    <div class="jumbotron"> 
    <div class="container">
        <centre>
          <div>
<form action="" class="bg-light needs-validation m-3" novalidate method="post" >
           
            
          

                <div class="col-6">
                     
                    <div class="form-group">
                <label for="validationCustom01">Phone number</label>
                <input type="text" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required name="phone" value="<?php echo $phone ?>" readonly="on">
                <br>
                <label for="validationCustom01">Customer Name</label>
                <input type="text" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required name="phone" value="<?php echo $name ?>" readonly="on">
                <br>
                 <div class="col-6">
                <label for="validationCustom01">Message</label>
                <textarea name="text" rows="10" width="10%" required=""></textarea> 
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter text
                </div>
              </div>
              <hr>


              <div class="col-md-6">
                
                <button name="send" class="btn btn-success col-6">Send Bonus</button>
              
              </div>
            </div>
          </div>
          
          </div>
          </div>
          </form>
        </centre>
      </div>

      </div>
  </div>
</div>
</div>
</body>
</html>