<?php
error_reporting(0);
include"auth.php";
include('connect/connect.php');
$id_cash = $_SESSION['cash'];
if (isset($_POST['reg'])) {
$a = htmlspecialchars($_POST['tax_name']);
$b = htmlspecialchars($_POST['tax_amount']);
    $sql = "INSERT INTO tax (tax_name,tax_amount) VALUES ('$a','$b')";
    $result = mysqli_query($conn,$sql);

if ($result) {
    echo"<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Successfully Added'
    data-type='success'>
    </div>";
    header("location:add_tax.php");

    }

}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
    <?php 

    if ($id_cash =='cashier') {
       include 'includes/cashiernav.php'; 
    }elseif($id_cash =='invetory'){
        include 'includes/inventorynav.php'; 
    }else{
        include 'includes/nav';
    }
    

    ?>
<div class='has-sidebar-left has-sidebar-tabs'>
 <div class='col'>
    <h1 class='s-2 mt-3'> <center>
        <?php include('system_name.php');?>
             </center>
         </h1>
     </div>
     <div class='card-body'>
        <div class="jumbotron">	
            <div class="container">
                <form action="" class="bg-light needs-validation m-3" novalidate method="post" style="border: 1px purple" >
            <div class="container">
            	<center>
                	<h3 class='card-header bg-white'>
                        <center>ADD NEW TAX OF PRODUCT
                    </h3>
                     </center>
                     <div class="row "><div class="col-6">
                    <div class="form-group">
                        <label for="validationCustom01">Tax name</label>
                        <input type="text" id="validationCustom01" class="form-control " placeholder="Enter tax name" aria-describedby="helpId" required name="tax_name" pattern="['Aa-Zz']" autofocus="on"><br>
                
            </div>
             <div class="form-group">
                        <label for="validationCustom01">Tax%</label>
                        <input type="number" id="validationCustom01" class="form-control " placeholder="Enter percentage" aria-describedby="helpId" required name="tax_amount" pattern="" autofocus=""><br>
                
            </div>
        </div>
<br>
<hr>
<div class="container">
    
<div class="form-group">
                
                    <button class="btn btn-secondary  col-md-6"  name="reg" style="background-color: purple;opacity: 0.4">Submit Details</button></center>
                    <div class="form-group"></div>
                </div>
                <hr>
            </div></div>

            <hr>
            </div>
        </div>
    </div>
</div>
</div>

</form>
</div>
</div>
</div>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
