<?php
error_reporting(0);
include 'auth.php';
include 'model/db_connection.php';
include 'model/userModel.php';
$id_cash = $_SESSION['cash'];
$userbranch=$_SESSION['inv'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
   <?php 

    if ($id_cash =='cashier') {
       include 'includes/cashiernav.php'; 
    }else{
        include 'includes/nav.php'; 
    }
    

    ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
             <div class='card my-3 no-b'>
                
                 <div class='card-body'>
                    <div class="table-responsive">
                        <center><h4 class="card-header">MANAGE YOUR EXPENSE HERE</h4></center><br>
                        <table id="example2" class="table table-bordered table-hover data-tables"
                               data-options='{ "paging": false; "searching":false}'>
                              
                            <thead>
                                 <tr >
                               <th>S/N</th>
                                <th>Expense name</th>
                                     <th>Branch Name</th>
                                     <th>Amount</th>
                                     <th>Date</th>
                                      <th>Show</th>
                            
                                      <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody class="record">
                                  <?php

                              $user = new userModel();
                              $datauser = $user->getExpenses1($userbranch);

                              $x = 1;
                              foreach ($datauser as $value) {
                                
                               ?>

                                <tr>
                                  <td><?php echo $x ?></td>
                                  <td><?php echo $value['expense_name']; ?></td>
                                  <td><?php echo $value['branch_name']; ?></td>
                                   <td><?php echo $value['amount']; ?></td>
                                    <td><?php echo $value['date']; ?></td>
                                     <td><a href="list_expense1.php" class="">
                                      <i class="icon icon-eye3 s-24 text-success"></i></a></td>
                                     <!--  <td><a href="exp_edit.php" class="">
                                      <i class="icon icon-edit s-24 text-primary"></i></a></td> -->
                                    <td><a href="exp_del.php?id=<?php echo $value['id_expenses']; ?>" class="">
                                      <i class="icon icon-trash s-24 text-danger"></i></a></td>
                                </tr>
                          <?php

                            $x++;

                           }

                           ?>

                            </tbody>
                            <tfoot>
                                  <tr >
                               <th>S/N</th>
                                <th>Expense name</th>
                                     <th>Branch Name</th>
                                     <th>Amount</th>
                                     <th>Date</th>
                                      <th>Show</th>
                                    
                                      <th>Delete</th>
                            </tr>
                            </tfoot>
                        </table>
                        </div>

                 </div>
            </div>
        </div>
    </div> 
</body>
<script src="assets/js/app.js"></script>


 <script type="text/javascript">

        
</script>

</html>