<?php 

include('connect/connect.php');
	
	if (isset($_GET['id'])) {
		$id=$_GET['id'];
	$sql ="DELETE FROM customer WHERE customer_id='$id'";
	$result=mysqli_query($conn,$sql);
	header("location:manage_customer.php");
	}
	if (isset($_GET['id'])) {
		$id = $_GET['id'];
	$sql ="DELETE FROM expense WHERE id_expenses='$id'";
	$result=mysqli_query($conn,$sql);
	header("location:list_expense.php");
	}
	


?>