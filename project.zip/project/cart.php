<?php 

session_start();
if (!isset($_SESSION['cart'])){
$_SESSION['cart'] = array();
}

if (isset($_POST['btn'])) {
			$cart  = array(
				'id' =>$_POST['id'],
				'cash'=>$_POST['cash'],
				'qty'=>$_POST['qty']
			);
		array_push($_SESSION['cart'],$cart);

		
}

if (isset($_POST['remove'])) {
	$idrem= $_POST['idcheck'];
	echo 	$idrem;
	array_keys($idrem);
	unset($_SESSION['cart'][$idrem]);
}

	$count=0;
foreach ($_SESSION['cart']  as $key=> $value) {
		echo $value['id']."<br>";
		echo $value['cash']."<br>";

		?> 
		<form method ='POST'>

		<input name='idcheck' type="hidden" value="<?php echo $count++; ?>"	>
		<input name='remove' type = 'submit'>
		</form>

<?php	}

foreach ($variable as $key => $value) {
	# code...
}


 ?>

 <!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST">
		<input type="text" name="id" value="<?php echo 2 ?>">
		<input type="text" name="cash" value="<?php echo 10000 ?>">
		<input type="text" name="qty" value="<?php echo 10 ?>">
		<input type="submit" value="Add Cart" name="btn">
	</form>
</body>
</html>



