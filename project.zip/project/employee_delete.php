<?php 
include('connect/connect.php');
	$id=$_GET['id'];
	$sql ="DELETE FROM user WHERE id='$id'";
	$result=mysqli_query($conn,$sql);
	//$success=base64_encode('success');
	header("location:employee_manage.php?hope=success");

?>