<?php
/* Database config */
$db_host		= 'localhost';
$db_user		= 'root';
$db_pass		= '';
$db_database	= 'sales'; 

/* End config */

$conn =mysqli_connect($db_host,$db_user, $db_pass,$db_database);

if (!$conn) {
	
	echo "fail to connect";
}

?>