<?php 
include 'auth.php';
include 'connect/connect.php';
include 'model/db_connection.php';
include 'model/userModel.php';
error_reporting(0);

$code_pro =  $_GET['valueone']; 
$code_branch = $_GET['code_branch'];
  
$sqlselect= "SELECT * FROM products WHERE product_code = '$code_pro' AND id_branch = '$code_branch '";
$results = mysqli_query($conn,$sqlselect);
$now_status= mysqli_fetch_array($results);
 echo "
    <div class='alert alert-danger text-dark'>

    PRODUCT NAME - " .$now_status['prod_name']."<br>
    PRODUCT CODE - ". $now_status['product_code']."<br>
    PURSCHASING PRICE - ". $now_status['purscasing_price']."<br>
    SELLING PRICE - " . $now_status['selling_price']."<br>
    ARRIVAL DATE - " . $now_status['arrival']."<br>
    EXPIRE DATE - ". $now_status['expiry_date']."</div>

        ";
   

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
     <link rel="stylesheet" href="assets/css/app.css">
</head>
</html>
                        