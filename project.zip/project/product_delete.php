<?php
include('connect/connect.php');

if (isset($_GET['id'])) {

	$id = $_GET['id'];

	$sql ="DELETE FROM tranfer WHERE id_product='$id'";
	$result=mysqli_query($conn,$sql);

	if ($result) {
		$sql ="DELETE FROM products WHERE product_id='$id'";
	$resultone=mysqli_query($conn,$sql);
		header("location:manage_product.php");
	}
	
}

?>