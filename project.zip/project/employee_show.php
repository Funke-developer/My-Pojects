<?php
include 'auth.php';
include 'model/db_connection.php';
include('connect/connect.php');
$id = $_GET['id'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
  <?php include 'includes/nav.php'; ?>
        <div class='has-sidebar-left has-sidebar-tabs'>
        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
             <div class='card my-3 no-b'>
                
                 <div class='card-body'>
                    <div class="table-responsive">
                        <center><h4 class="card-header">EMPLOYEE SCHEDULE (TIME TABLE)</h4></center><br>
                        <table id="example2" class="table table-bordered table-hover data-tables"
                               data-options='{ "paging": false; "searching":false}'>
                              
                            <thead>
                                 <tr>
                                <th>Day</th>
                                <th>Week</th>
                                <th>Month</th>
                                <th>Year</th>
                            </tr>
                            </thead>
                            <tbody>
                                  <?php

                                    $sql = "SELECT * FROM schedule WHERE employee_id= '$id' ";
                                    $results = mysqli_query($conn,$sql);
                                    while ($fetch = mysqli_fetch_array($results)) { ?>

                                      <tr>
                                  
                                  <td><?php echo $fetch['day']; ?></td>
                                  <td><?php echo $fetch['week']; ?></td>
                                   <td><?php echo $fetch['mon']; ?></td>
                                    <td><?php echo $fetch['years']; ?></td>
                                       </tr>
                                     
                                 
                          <?php }

                           ?>

                              
                        
                            </tbody>
                            <tfoot>
                                 <tr>
                               <th>Day</th>
                                <th>Week</th>
                                <th>Month</th>
                                <th>Year</th>
                            </tr>
                            </tfoot>
                        </table>
                        </div>

                 </div>
            </div>
        </div>
    </div> 
</body>
<script src="assets/js/app.js"></script>
 

</html>