<?php 
include('connect/connect.php');
error_reporting(1);
$sql="SELECT * FROM customer";
$result=mysqli_query($conn,$sql);
$recepientArray = array();

$recId = 3;
while($fetch_phone=mysqli_fetch_array($result)){
    $phone=$fetch_phone['contact'];
    $customerArray = array("recipient_id"=>$recId,"dest_addr"=>$phone);
    array_push($recepientArray, $customerArray);
    $recId++;
}

$date=date("d-m-Y");
$msg = "Ndugu mteja wa supermarket yetu tunakukaribisha leo tarehe $date kuna bonus inatolewa kwa bidhaa zetu bidhaa zitauzwa kwa bei nafuu sana hivyo unakaribishwa";

//.... replace <api_key> and <secret_key> with the valid keys obtained from the platform, under profile>authentication information
$api_key= "ad475642d371aece";
$secret_key = "YzY0ZWQ5OTk5ZWFmOWE4MmZkNmYxNTY0MWViZGExYTZjMDE5MTkzMGIwN2VkMzY0Y2M4MWNiMTZhZDYwMzYyMg==";
// The data to send to the API
$postData = array(
    'source_addr' => 'INFO',
    'encoding'=>0,
    'schedule_time' => '',
    'message' => $msg,
    'recipients' => $recepientArray
);
//.... Api url
$Url ='https://apisms.bongolive.africa/v1/send';

// Setup cURL
$ch = curl_init($Url);
error_reporting(E_ALL);
ini_set('display_errors', 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt_array($ch, array(
    CURLOPT_POST => TRUE,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_HTTPHEADER => array(
        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
        'Content-Type: application/json'
    ),
    CURLOPT_POSTFIELDS => json_encode($postData)
));

// Send the request
$response = curl_exec($ch);

// Check for errors
if($response === FALSE){
        //echo $response;
echo"<div class='toast bg-brown'
    data-title='Authentification Centre'
    data-message='New Bonus Are Not Successfully Send To customer with phone number $phone'
    data-type='errors'> 
    </div>";
    //die(curl_error($ch));
}

echo"<div class='toast bg-brown'
    data-title='Authentification Centre'
    data-message='New Bonus Are Successfully Send To customer with phone number $phone'
    data-type='success'> 
    </div>";
    header("location:send.php");
//var_dump($response);}

?>



