<?php
include"auth.php";
include('model/db_connection.php');
include('model/userModel.php');
require('fpdf/fpdf/fpdf.php');
include('connect/connect.php');
$pdf = new FPDF();
$pdf->AddPage('P','A3','mm');
$pdf->SetFont('Arial','',10);
$pdf->SetFont('Arial','B',20);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(260,10,'',0,1,'C');
$pdf->Cell(260,30,'PRODUCT INFORMATION TRACKING SYSTEM',0,1,'C');
$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(260,10,'REPORT OF ALL SALES',0,1,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'No',1,0,'C');
$pdf->Cell(50,10,'TRANSACTION ID ',1,0,'C');
$pdf->Cell(50,10,' INVOICE NUMBER',1,0,'C');
$pdf->Cell(50,10,' CUSTOMER CODE ',1,0,'C');
$pdf->Cell(30,10,'QYT',1,0,'C');
$pdf->Cell(30,10,' DATE ',1,0,'C');
$pdf->Cell(30,10,' AMOUNT',1,1,'C');


$tarehe= date('d-m-Y');
$user = new userModel();
$sql = "SELECT * FROM `sales` ORDER BY `sales`.`transaction_id` ASC";
		$result = mysqli_query($conn,$sql);
		
$x = 1;
while ($row = mysqli_fetch_array($result)) {
$pdf->SetFont('Arial','',10);
$pdf->Cell(10,10,$x,1,0,'C');
$pdf->Cell(50,10,$row['transaction_id'],1,0,'C');
$pdf->Cell(50,10,$row['invoice_number'],1,0,'L');
$pdf->Cell(50,10,$row['customer_id'],1,0,'R');
$pdf->SetTextColor(255,0,0);
$pdf->Cell(30,10,$row['qty'],1,0,'R');
$pdf->SetTextColor(0,0,0);
$pdf->Cell(30,10,$row['date'],1,0,'C'); 
$pdf->Cell(30,10,$row['amount'],1,1,'L');

$pdf->SetTextColor(0,0,0);
$x++;
}
$pdf->Cell(70,20,'',0,1,'C');
$pdf->SetFont('Arial','',17);
$pdf->Cell(200,10,'Report on date: '.date('l-d-m-y'),0,1);
$pdf->Output();

?>