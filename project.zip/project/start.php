
<!DOCTYPE html>
<html>
<head>
	<title>SOKOINE UNIVERSITY OF AGRICULTURE  STAFF  INFORMATION  SYSTEM</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="fontawasome\css\all.css">
<link rel="stylesheet" href="assets/css/app.css">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
	 
	<style type="text/css">
		.card_shadow{
			box-shadow: 0px 0px 15px rgba(0,0,0,0.2) ;
			border:none;
			border-radius: 10px;
			
		}
		.rows{
			box-shadow: 0px 0px 3px rgba(0,0,0,0.4) ;

		}
		.th_check{
			box-shadow: 0px 0px 3px rgba(0,0,0,0.4) ;	
		}
		.table-header td{
			
		}
		 marquee {
        width: 100%;
        height:15px;
        padding: 5px 0;
        background-color: ;
    
		     
		 }
	</style>
</head>
<body >
	<div class="container-fluid" style="background-color: #FBFBFB;">
		<div class="container " style="margin-top: 10px;">
			<div class="row ">
			<div class="col-md-12 text-justify">
				<center>
			    <h2 class="text-centre" style="color:#04600A;">
			        SOKOINE UNIVERSITY OF AGRICULTURE OPEN REVIEW AND APPRAISAL SYSTEM
			        </h2>
			    </center>
			        </div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-8 mt-md-4 mb-md-4 ">
					<div class="card pl-2 pr-2 card_shadow"  >
						<h6 class="card-header" style=" text-transform: uppercase; color:#04600A;background-color: white; border-bottom: 2px solid  #0CE947;">
						<center class="">
							This form is intended to meet the requirements of 
                                        the performance management system and development process.<br>
                                    (To be filled in Triplicate)
                                      From   July  <?php echo date("Y");?>...... to June  <?php echo date("Y");?><br><br>
                                    </center>NOTES ON HOW TO FILL THIS FORM:</h6>
						<div class="card-body">
						<div class="card-body">
							<div class="container alert alert-info  text-justify">
1.This Form must be filled at the beginning, mid and at the end of the financial year.<br><br>
2.This Form must be filled by all members of staff at the end of the year, once fully completed, the DVCs should send original to the Vice Chancellor, Deans and Directors should send original to the DVC (Academic) and Heads of Administrative Department should send original copies to the DVC (Administration and Finance). Heads of Academic Departments should send originals to their respective Deans and Directors.  The other staff should send originals to their respective Heads of Departments.</br><br>

3.Where appropriate, each box shall carry only one letter or figure.  Letters to be in capitals.<br><br>

4.Personal/Agreed objectives are derived from the Organisation’s work plan (Strategic plan, Annual operating plans or Action plans) and are expected to be implemented in the current year.<br><br>

5.Sections 2, 3 and 4 of this Form shall be filled by the Appraisee in consultation with the Supervisor and sections 5-6 in the presence of a third party if necessary.<br><br>

6.Please note that appraisals that are rated as 1 are the best performers and appraisals rated as 5 are the worst performers.  These should be brought to the attention of top management and usually to the attention of the Vice Chancellor.
</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4 mt-4 mb-4">
		<div class="card pl-2 pr-2 
		card_shadow">

				<div class="card-body"> 
					FILL PERSONAL INFORMATION
					    	 <hr class="bg-success">
					    	 <div class="alert alert-danger">
					    
						 For All New And Available Staffs You Must Visit This<span class="">
						 	<span class="text-danger">OPEN REVIEW AND APPRAISAL  SYSTEM
			        </span> </span > To Fill The Required Information .
					</div><hr class="text-success">
						</p>
								<span style="padding-left: 10px;">
								
							</div>
					
						<p></p>
							<div class='col-md-12 mt-6'>
					<centre>
						<br><br>
						<a href="step_one.php" class="btn btn-success offset-md-3 col-md-7" style="border:1px solid white;" target="">SECTION ONE</a>
						<br><br>
					</centre>
				</div>
				<br>
				<div style="" class="container">
					<div class="" style="margin-top:140px">
						<small>
							<p class="">FIRST ROUND :
								<span class="text-danger">Open of the Financial Year
								</span>
							SECOND ROUND:<span class="text-danger">Middle of the Financial Year 
							</span>
						THIRD ROUND:<span class="text-danger">End of the Financial Year</span>
						</p>
					</small>
					</div>
			</div>
				</div>		
		</div>   

		</div>
	</div>
</div>
<script src="assets/js/app.js"></script>
</div>
</body>
</html>
			