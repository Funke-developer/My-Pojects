<?php 
error_reporting(0);
include('connect/connect.php');
if (isset($_GET['value'])) {
	$id_branch =$_GET['value'];
	$sql = "SELECT * FROM products WHERE id_branch = '$id_branch' AND dig = 0 order by product_code desc ";
  $results = mysqli_query($conn,$sql);
   $num = mysqli_fetch_array($results); 
   $product_codev = 1 + $num['product_code'];
   if ($product_codev == 1) {
   	echo"<input type='text'   class='form-control ' aria-describedby='helpId' name='code' value='19980718200010000' readonly>";   
   }else{
   	echo"<input type='text'   class='form-control ' aria-describedby='helpId' name='code' value='".$product_codev."' readonly>";
   }

   
}
   
                
?>1