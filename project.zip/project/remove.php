
<?php
session_start();
if (isset($_GET['code'])) {
  $y = $_GET['code'];
  $index = 0;
  $removearray = array();
  foreach ($_SESSION['cart'] as $valuecode) {
    if ($y != $index) {
      array_push($removearray,$valuecode);
    }
    $index++;
  }
 $_SESSION['cart']  = $removearray;
 
 header('location:sales.php');
}


?>