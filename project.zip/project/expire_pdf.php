<?php
include"auth.php";
include('model/db_connection.php');
include('model/userModel.php');
require('fpdf/fpdf/fpdf.php');
include('connect/connect.php');

$pdf = new FPDF();
$pdf->AddPage('P','A3','mm');

// $pdf->Cell(40,10,'Helgygcduycgudygcvyugfvyu',1,0,1,'C');
$pdf->SetFont('Arial','',10);
// Move to 8 cm to the right
$pdf->SetFont('Arial','B',20);
$pdf->SetTextColor(0,0,0);
// Centered text in a framed 20*10 mm cell and line break
// $pdf->Image('image/download1.png',10,10,-300); 

$pdf->Cell(260,10,'',0,1,'C');
$pdf->Cell(260,30,'PRODUCT INFORMATION TRACKING SYSTEM',0,1,'C');


$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,0,0);
// Centered text in a framed 20*10 mm cell and line break
$pdf->Cell(260,10,'ALL EXPENSES REPORTS',0,1,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'No',1,0,'C');
$pdf->Cell(40,10,'PRODUCT CODE ',1,0,'C');
//$pdf->Cell(60,10,'FULLNAME',1,0,'C');
$pdf->Cell(40,10,'PRODUCT NAME  ',1,0,'C');

$pdf->Cell(30,10,'QUANTINTY ',1,0,'C');
$pdf->Cell(40,10,'EXPIRE DATE ',1,0,'C');
$pdf->Cell(40,10,' ARRIVAL DATE',1,0,'C');
$pdf->Cell(40,10,' BRANCH NAME',1,0,'C');
$pdf->Cell(40,10,'  STATUS',1,1,'C');
$tarehe= date('d-m-Y');
 $user = new userModel();
  $datauser = $user->getProductExpired();

  $x = 1;
        foreach ($datauser as $row) {


$pdf->SetFont('Arial','',10);
$pdf->Cell(10,10,$x,1,0,'C');
$pdf->Cell(40,10,$row['product_code'],1,0,'C');
//$pdf->Cell(60,10,$row['fullname'],1,0,'C');
$pdf->Cell(40,10,$row['prod_name'],1,0,'C');
$pdf->Cell(30,10,$row['quantinty'],1,0,'R');
$pdf->Cell(40,10,$row['expiry_date'],1,0,'R');
$pdf->Cell(40,10,$row['arrival'],1,0,'R'); 
$pdf->Cell(40,10,$row['branch_name'],1,0,'C'); 
$pdf->SetTextColor(255,0,0);
$pdf->Cell(40,10,'Expired never sell',1,1,'C'); 
$pdf->SetTextColor(0,0,0);
$x++;
}

$pdf->Cell(70,20,'',0,1,'C');
$pdf->SetFont('Arial','',17);

$pdf->Cell(200,10,'Report on date: '.date('l-d-m-y'),0,1);



$pdf->Output();

?>