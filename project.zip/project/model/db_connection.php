<?php 
class db_connection {
    public function connection(){
        $conn = mysqli_connect("localhost","root","","sales");
        return $conn;
        if(!$conn){
    die();
        }
    }
}
?>