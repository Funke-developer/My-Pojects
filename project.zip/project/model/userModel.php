<?php 
class userModel extends db_connection{
	public function loginInfo($email,$pass){
		$sql = "SELECT * FROM user WHERE username= '$email'  and password ='$pass'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		return $data;
	}

	public function checkbranch($id_branch){
		$sql = "SELECT * FROM branch WHERE id = '$id_branch' ";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		return $data;
	}
	public function getSale(){
		$sql = "SELECT * FROM `sales` ORDER BY `sales`.`transaction_id` ASC ";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		return $data;
	}



	public function getCustomerBonus(){
		$sql = "SELECT * FROM sales where amount>100000 order by `date` asc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}

	
	public function getProductTransfered(){
		$sql = "SELECT * FROM tranfer join branch on tranfer.now_branch = branch.id join products on products.product_id = tranfer.id_product";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}

	public function getCustomer(){
		$sql = "SELECT * FROM customer order by customer_name asc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}
		public function getBranch(){
		$sql = "SELECT * FROM `branch` order by branch_name asc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}

public function getTransfered(){
	
		$sql = "SELECT sum(qty) FROM `tranfer` where status='Approved'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	public function getTransfered1($userbranch){
	
		$sql = "SELECT sum(qty) FROM `tranfer` where status='Approved' and pre_branch='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}


public function getsells(){
		$sql = "SELECT sum(amount) FROM `sales` ";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}

	public function getPurschasing8($userbranch){
		$sql = "SELECT sum(purscasing_price) FROM `products` where id_branch='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}

public function getPurschasing(){
		$sql = "SELECT sum(purscasing_price) FROM `products` ";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	public function getExpired(){
		$date=date('Y-m-d');
		$sql = "SELECT sum(quantinty) FROM `products` where expiry_date <'$date' order by expiry_date desc";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}

	

public function getProductExpired(){
	$date=date("Y-m-d");

		$sql = "SELECT * FROM products join branch on products.id_branch = branch.id join tax on products.tax_id = tax.tax_id join category on category.category_id = products.category_id where expiry_date<= '$date' order by expiry_date,branch_name desc ";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;

	}

public function getProductExpired1($userbranch){
	$date=date("Y-m-d");

		$sql = "SELECT * FROM products join branch on products.id_branch = branch.id join tax on products.tax_id = tax.tax_id join category on category.category_id = products.category_id where expiry_date<= '$date' and id_branch='$userbranch' order by expiry_date desc ";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;

	}


	
	public function getProductstock1($userbranch){

		$sql = "SELECT * FROM products join branch on products.id_branch = branch.id join tax on products.tax_id = tax.tax_id join category on category.category_id = products.category_id where  quantinty < 200 AND id_branch='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;

	}

	public function getProductstock(){

		$sql = "SELECT * FROM products join branch on products.id_branch = branch.id join tax on products.tax_id = tax.tax_id join category on category.category_id = products.category_id where  quantinty < 200 ";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;

	}
	public function getProduct(){

		$sql = "SELECT * FROM products join branch on products.id_branch = branch.id join tax on products.tax_id = tax.tax_id join category on category.category_id = products.category_id order by products.prod_name";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;

	}
	
	public function getProductBranch($userbranch){

		$sql = "SELECT * FROM products join branch on products.id_branch = branch.id join tax on products.tax_id = tax.tax_id join category on category.category_id = products.category_id where products.id_branch='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;

	}
   public function delAlluser($username){
		$sql_admin="DELETE FROM `user` WHERE username='$username' ";
		$results__get = mysqli_query($this->connection(),$sql_admin);
		$sql_applicant_all = mysqli_fetch_all($results__get,MYSQLI_ASSOC);
		return $sql_applicant_all;
	}


			public function getUser1(){
		$sql = "SELECT brranch.id AS branch,username,position,branch_name,name FROM user join branch on branch.id=user.branch_id";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}
		
		public function getUser(){
		$sql = "SELECT * FROM user join branch on branch.id=user.branch_id order by branch_name asc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}

	public function getlog(){
		$sql = "SELECT * FROM userlog order by id desc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}


	public function getCustomerToedit($id){
$sql="SELECT * FROM customer WHERE customer_id='$id'";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}
			public function getSumExpense1($userbranch){
		$sql="SELECT SUM(amount) FROM expense where brnch_id='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}


		public function getSumExpense(){
		$sql="SELECT SUM(amount) FROM expense";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}

        public function getEmployeeTotal(){
		$sql = "SELECT * FROM user";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}

  public function getEmployeeTotal1($userbranch){
		$sql = "SELECT * FROM user where branch_id='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}
        public function getCustomerTotal(){
		$sql = "SELECT * FROM customer";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}

	    public function getProductTotal(){
		$sql = "SELECT sum(quantinty) FROM products";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	 public function getProductTotal1($userbranch){
		$sql = "SELECT sum(quantinty) FROM products where id_branch='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	    public function getBranchTotal(){
		$sql = "SELECT * FROM branch";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result); 
		return $numRows;
	}
	
	 public function getProductNearToExpire(){
		$sql = "SELECT * FROM `sales` ORDER BY `sales`.`transaction_id` ASC ";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result)>1; 
		return $numRows;
	}

        public function Checknumber(){
		$sql = "SELECT membership_number FROM customer";
		$result = mysqli_query($this->connection(),$sql);
		$numRows = mysqli_num_rows($result)>1; 
		return $numRows;
	}
	public function getExpenses(){
		$sql = "SELECT * FROM expense join branch on expense.brnch_id=branch.id";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	
	}



	public function getExpenses1($userbranch){
		$sql = "SELECT * FROM expense join branch on expense.brnch_id=branch.id where expense.brnch_id='$userbranch'";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	
	}
	public function getCategory(){
		$sql = "SELECT * FROM category order by category asc";
		$result = mysqli_query($this->connection(),$sql);
				$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	
	}
	public function getTax(){
		$sql="SELECT *FROM tax order by tax_name asc";
		$result=mysqli_query($this->connection(),$sql);
		$data=array();
		while ($arrayData=(mysqli_fetch_array($result))) {
			array_push($data,$arrayData);

			# code...
		}
		return $data;
	}

	
	public function getProductExpired8($userbranch){
	    $date=date("Y-m-d");

		$sql = "SELECT sum(quantinty) FROM products join branch on products.id_branch = branch.id join tax on products.tax_id = tax.tax_id join category on category.category_id = products.category_id where expiry_date<= '$date' and id_branch='$userbranch' order by expiry_date desc ";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	
	
		public function getNumtotalahadiToday1($date,$time){
		$sql="SELECT SUM(ahadi) FROM matoleo WHERE tarehe ='$date' AND time='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getNumtotaljengoToday1($date,$time){
		$sql="SELECT SUM(jengo) FROM matoleo WHERE tarehe ='$date' AND time='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getNumtotalahadiToday($date){
		$sql="SELECT SUM(ahadi) FROM matoleo WHERE tarehe ='$date'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getNumtotaljengoToday($date){
		$sql="SELECT SUM(jengo) FROM matoleo WHERE tarehe ='$date'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getViongoziAhadizote(){
        $sql="SELECT * FROM `agano` join orodha_kuu on 
        agano.bahasha_namba = orodha_kuu.id ORDER BY `hali` ASC ";
        $result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}

		return $arrayData;
	}

	
		public function getsummitaa($date,$time){
		$sql="SELECT SUM(sad_za_mitaa ) FROM matoleo WHERE tarehe ='$date' AND ibada='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
		public function getsumjumuia($date,$time){
		$sql="SELECT SUM(sad_za_jumuiya) FROM matoleo WHERE tarehe ='$date' AND ibada='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
	
	
	
	public function getWauminipdfhusika($date1){

$sql="SELECT * FROM matoleo WHERE matoleo.tarehe ='$date1' order by tarehe desc";
		$result = mysqli_query($this->connection(),$sql);
		$arrayData =array();
		while ($data = mysqli_fetch_array($result)) {
			array_push($arrayData,$data);
		}
		return $arrayData;
	}
		public function getsumschool($date,$time){
		$sql="SELECT SUM(sunday_school) FROM matoleo WHERE tarehe ='$date' AND ibada='$time'";
		$result = mysqli_query($this->connection(),$sql);
		$data = mysqli_fetch_array($result);
		$total = $data[0];
		return $total;
	}
}
?>

