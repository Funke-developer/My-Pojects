<?php


echo "<div class='container'><centre><h3 class='offset-2 card-header offset-0.5 pr-2' style='color: #04600A'>
PRODUCT INFORMATION TRACKING SYSTEM  
</h3>
</centre>
</div>";

?>
