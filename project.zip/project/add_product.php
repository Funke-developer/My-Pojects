<?php
error_reporting(0);
include("auth.php");
include('connect/connect.php');
include 'model/db_connection.php';
include("model/userModel.php");

$class=new userModel();
$data=$class->getCategory();
$datatax=$class->getTax();
$dataBranch=$class->getBranch();
$id_cash = $_SESSION['cash']; 

 $id_branch =  $_SESSION['inv'];

if (isset($_POST['reg'])) {

$product_code = $_POST['code'];
$product_name = $_POST['name'];
$purchasing_price = $_POST['purchasing_price'];
$product_quantity = $_POST['product_quantity'];
$tax = $_POST['tax'];
$category= $_POST['category'];
$selling = $_POST['selling'];
$arrival = $_POST['arrival'];
$expire = $_POST['expire'];
$ingredient = $_POST['ingredient'];
$ingredient2 = $_POST['ingredient2'];
$branch = $_POST['branch_name'];

$sql = "SELECT * FROM products";
$results = mysqli_query($conn,$sql);
$num = mysqli_num_rows($results);

if ($num <= 0) {

    $product_codey =19980718200010000; 

    $sql = "INSERT INTO `products` (`product_id`, `product_code`, `prod_name`, `purscasing_price`, `quantinty`, `category_id`, `tax_id`, `selling_price`, `arrival`, `expiry_date`, `id_branch`,`ingredient`,`ingredient2`) VALUES (NULL, '$product_codey', '$product_name', '$purchasing_price', '$product_quantity', '$category', '$tax', '$selling', '$arrival', '$expire', '$branch','$ingredient','$ingredient2')";
$result = mysqli_query($conn,$sql);
if ($result) {
     echo"<div class='toast bg-brown'
    data-title='Authentification Centre'
    data-message='New customer Added Successfully'
    data-type='success'> 
    </div>";

header("location:add_product.php");
}
    # code...
}else{

    $sql = "INSERT INTO `products` (`product_id`, `product_code`, `prod_name`, `purscasing_price`, `quantinty`, `category_id`, `tax_id`, `selling_price`, `arrival`, `expiry_date`, `id_branch`,`ingredient`,`ingredient2`) VALUES (NULL, '$product_code', '$product_name', '$purchasing_price', '$product_quantity', '$category', '$tax', '$selling', '$arrival', '$expire', '$branch','$ingredient','$ingredient2')";
$result = mysqli_query($conn,$sql);
if ($result) {
     echo"<div class='toast bg-brown'
    data-title='Authentification Centre'
    data-message='New customer Added Successfully'
    data-type='success'> 
    </div>";

header("location:add_product.php");
}

}


}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="light sidebar-mini sidebar-collapse">
     <?php 

    if ($id_cash =='invetory') {
       include("includes/inventorynav.php");
    }else{
        include 'includes/nav.php'; 
    }
    

    ?>
        <div class='has-sidebar-left has-sidebar-tabs'>

<h3 class='card-header bg-white'> <center>
    <div class='col'>
    <h1 class='s-2 mt-3'> <center>
        <?php include('system_name.php');?>
             </center>
         </h1></div>
    
</center></h3>
<div class='card-body'>
	<div class="jumbotron">	
	<div class="container">
		
<form action="" class="bg-light needs-validation m-3" novalidate method="post" style="border: 1px purple" >
           
            <div class="container">
            	<center>
                	<h3 class='card-header bg-white'> <center>ADD NEW PRODUCTS DETAILS</center></h3>
                     </center>
            <div class="row ">
            <div class="col-6"> 
                  <div class="form-group">
            
                <label for="validationCustom01">Select Branch</label>
                <select class="form-control" name="branch_name" onchange="getProject(this.value)" >
                    <option selected disabled="on">Select Branch</option>

                <?php 
                foreach ($dataBranch as  $value) {
                    echo"
                       <option value=".$value['id'].">".$value['branch_name']."</option>";
                
                }

                ?>
                 
                </select>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter branch
                </div>

            </div>
            </div>

                  <div class="col-6">
                     
                    <div class="form-group">
                <label for="validationCustom01">Product Name</label>
                <input type="text" name="name" id="validationCustom01" class="form-control " placeholder="Product Name" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter name
                </div>

            </div>
          </div>
            </div>

            <div class="row ">
                 <div class="col">
                     <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Purchasing price</label>
                <input type="number" name="purchasing_price" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required >
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter purchasing
                </div>

            </div>

                </div>
                 <div class="col">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Total Quanty</label>
                <input type="number" name="product_quantity" id="validationCustom01" class="form-control " placeholder="" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  Jaza total
                </div>

            </div>


                </div>
            </div>
             <div class="row ">

                <div class="col-6">
                   
                    <div class="form-group">
                      
                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Enter Tax Type </label>
                <select class="form-control" name="tax">
                    <option selected disabled="on">Enter Tax Type</option>
                    <?php 
                foreach ($datatax as  $value) {
                    echo"
                       <option value=".$value['tax_id'].">".$value['tax_name']."</option>";
                
                }



                ?>
                </select>
                
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                    enter date
                </div>

            </div>
          </div>
                
               
        
                 <div class="col">
            <div class="form-group">


                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Select Product Category</label>
                <select class="form-control" name="category" >
                    <option selected disabled="on">Select Product Category</option>

                <?php 
                foreach ($data as  $value) {
                    echo"
                       <option value=".$value['category_id'].">".$value['category']."</option>";
                
                }

                ?>
                 
                </select>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter category
                </div>

            </div>



               
            </div>
            
        
            <br>
            <hr>
           <div class="container">
  <div class="row ">
    <div class="col-4">
            <div class="form-group">
                <label for="validationCustom01">selling Price </label>
                <input type="number" name="selling" id="validationCustom01" class="form-control " placeholder="selling Price" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter selling price
                </div>

            </div>

                </div>
        
                 <div class="col-4">
            <div class="form-group">
                <label for="validationCustom01">Manufacturing Date</label>
                <input type="date" name="arrival" id="validationCustom01" class="form-control " placeholder="profit" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter arrival date
                </div>

            </div>
            </div>
            
         <div class="col-4">
            <div class="form-group">

                <!-- <label for="Registration number">Registration number</label> -->
                <label for="validationCustom01">Expire date</label>
                <input type="date" name="expire" id="validationCustom01" class="form-control " placeholder="profit" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter expire date
                </div>

            </div>
        </div>
        <div class="container">
        <div class="row ">
    <div class="col-4">
            <div class="form-group">
                <label for="validationCustom01"> Ingredient </label>
                <input type="text" name="ingredient" id="validationCustom01" class="form-control " placeholder="ingredient" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter ingredient
                </div>

            </div>

                </div>
        
                 <div class="col-4">
            <div class="form-group">
                <label for="validationCustom01">ingredient</label>
                <input type="text" name="ingredient2" id="validationCustom01" class="form-control " placeholder="ingredient" aria-describedby="helpId" required>
                <div class="valid-feedback">
                    Looks good!
                </div>
                <div class="invalid-feedback">
                  enter ingredient
                </div>

            </div>
            </div>

             <div class="col-4">
                <label for="validationCustom01">Product Code number</label>     
            <div class="form-group" id="get_project_id" >
                
                
            </div>
          </div>
                           
            </div>
            <br>
            <hr>
        </div>
</div>
</div>
</div>
</div>
<center>
<div class="container">
    <div class="form-group">
                <button class="btn btn-secondary  col-6"  name="reg" style="background-color: purple;opacity: 0.4">Submit Details</button>
                <div class="form-group"></div>
                <hr>
                </div>
            </div>
        </center>
            </div>
            <br>
        </form>
    </div>

    </div>
</div>

<script src="assets/js/app.js"></script>
    <script type="text/javascript">

    function getProject(value) {

    xhr = new XMLHttpRequest();

    xhr.open('GET','apiv.php?value='+value,true);

    xhr.onload = function () {

        document.getElementById('get_project_id').innerHTML = this.responseText; 
    }

    xhr.send();

    }
   
</script>
</body>
</html>
