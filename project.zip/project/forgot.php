<?php
include('connect/connect.php');
if (isset($_POST['login'])) {

    $phone=$_POST['phone'];
    $sql="SELECT * FROM user WHERE contact='$phone'";
    $result=mysqli_query($conn,$sql);
    if (mysqli_num_rows($result)<=0) {
        // code...
    
echo "<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Phone Number not exist'
    data-type='error'> 
    </div>";
    }
    else{

    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
     //turn the array into a string

$password=implode($pass);
}
$update_data="UPDATE user SET password='$password' WHERE contact='$phone'";
$update_data_result=mysqli_query($conn,$update_data);

        if ($update_data_result) {

             $phone=$_POST['phone'];
            $date=date("d-m-Y");
$msg = "Ndugu tumia password hii $password kuingia kwenye account yako";

//.... replace <api_key> and <secret_key> with the valid keys obtained from the platform, under profile>authentication information
$api_key= "ad475642d371aece";
$secret_key = "YzY0ZWQ5OTk5ZWFmOWE4MmZkNmYxNTY0MWViZGExYTZjMDE5MTkzMGIwN2VkMzY0Y2M4MWNiMTZhZDYwMzYyMg==";
// The data to send to the API
$postData = array(
    'source_addr' => 'INFO',
    'encoding'=>0,
    'schedule_time' => '',
    'message' => $msg,
    'recipients' => array(["recipient_id"=>1,"dest_addr"=>$phone]),
);
//.... Api url
$Url ='https://apisms.bongolive.africa/v1/send';

// Setup cURL
$ch = curl_init($Url);
error_reporting(E_ALL);
ini_set('display_errors', 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt_array($ch, array(
    CURLOPT_POST => TRUE,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_HTTPHEADER => array(
        'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
        'Content-Type: application/json'
    ),
    CURLOPT_POSTFIELDS => json_encode($postData)
));

// Send the request
$response = curl_exec($ch);

// Check for errors
if($response === FALSE){
        //echo $response;
  header("location:index.php?reset_error=warning");
    //(curl_error($ch));
}
else{

     header("location:index.php?reset_message=warning");

  
//var_dump($response);
}

           
    }
    
}
}

?>
<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEMS</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/app.css">

</head>
<body class="light sidebar-mini sidebar-collapse">

<div id="app">
<main>
    <div id="primary" class="p-t-b-40 height-full bg-light">
        <div class="container " >
            <div class="row">
                <div class="col-lg-4 mx-md-auto paper-card ">
                    <div class="text-center mb-4">
                        <h3 class="" style="color: #4600A0">PRODUCT INFORMATION TRACKING SYSTEM</h3>
                         <center><h4 class="card-header" style="color: #04600A;">
                          <img src="image/images.jpg">
                                              <br> 
                                      <h6 class="mt-2" style="color: #4600A0" >Update Your Password</h6>
                        <p></p>
                      
                    </div>
                    <form action="" method="POST">
                        <div class="form-group has-icon"><i class="icon-envelope-o"></i>
                    <input type="text" class="form-control form-control-lg" placeholder="Enter Phone number" name="phone" required>
                        </div>
                        <button type="submit" name="login" class="btn bg-secondary btn-lg btn-block text-white">Submit</button>
                        <p></p>
                       <!--  <p class="forget-pass"><h6><spans tyle="color: #4600A">Forgot password?</span> <a href="forgot.php">Click here</a></h6></p> --> 
                         <p class="forget-pass"><h6 style="display: none;">
                            <spans tyle="color: #4600A">Forgot password?
                            </span> <a href="forgot.php">Click here to reset</a></h6></p>
                            <p class="">
                             <center>
                                 
                           <h6 style="display: ;">
                                    <spans tyle="color: black">
                                    </span> 
                                    <a href="index.php">Click here to Login</a>
                                </h6>  </center>   
                                </p>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- #primary -->
</main>

</div>
<!--/#app -->
<script src="assets/js/app.js"></script>
<center><?php include('footer.php');?></center>
</body>
</html>