<?php 
include('auth.php');
error_reporting(0);
include 'connect/connect.php';
$userbranch=$_SESSION['inv'];




 if(isset($_POST['clear'])){
        unset($_SESSION['cus']);
    unset($_SESSION['cart']);
     }

if (isset($_SESSION['cash'])) {
$id_cash = $_SESSION['cash'];
}


if (!isset($_SESSION['cart'])){
		$_SESSION['cart'] = array();	
	}

if (isset($_POST['add'])) {

    $code_pro = $_POST['product_code'];
    $branch = $_POST['branch'];
    $cus_pro = $_POST['cus_code'];
    $_SESSION['cus'] = $cus_pro;
    $qua = $_POST['qty'];

    // echo $code_pro;
    // echo $branch;

    $sqlcheck = "SELECT * FROM products WHERE id_branch = '$branch' AND product_code = '$code_pro'";
    $results = mysqli_query($conn,$sqlcheck);
    $now_check = mysqli_fetch_array($results);

    if ($now_check['quantinty'] < $qua) {

          echo "<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Sales Not Added Less Product'
    data-type='info'>
    </div>";
    }else{

    $sqlcheck1 = "SELECT * FROM products WHERE id_branch = '$branch' AND product_code = '$code_pro'";
    $results1 = mysqli_query($conn,$sqlcheck1);
    $now_check1 = mysqli_fetch_array($results1);

    if ($now_check1['expiry_date'] <= date('Y-m-d')) {

        echo "<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Product already Expired'
    data-type='error'>
    </div>";

    }else{

        $count = count($_SESSION['cart']);
         $_SESSION['cus'] =  $_POST['cus_code'];
        echo $count;
            $cart  = array(
                'id' =>$_POST['product_code'],
                'cush'=> $_POST['cus_code'],
                'branch'=>$_POST['branch'],
                 'price' => $_POST['price'],
                'qty'=>$_POST['qty']

            );


     array_push($_SESSION['cart'],$cart);

    }
        
    }
}

if (isset($_POST['code'])) {
    
    foreach($_SESSION['cart'] as $value){

        $selectincome = "SELECT * FROM sales";
        $sql_query = mysqli_query($conn,$selectincome);
        $num_sales = mysqli_num_rows($sql_query);

        $mount= $value['qty'] * $value['price'];
        $date = Date("Y-m-d");
        $qtyone = $value['qty'];
       $cush =  $value['cush'];

        if ($num_sales <= 0 ) {
        $income = "RS-";
        $x = 0000;
        $come_rs = $income.''.$x;
        $ins_pro = "INSERT INTO sales VALUES(NULL,'$come_rs','$id_cash','$date','$mount','$cush','$qtyone')";
        $query_data = mysqli_query($conn,$ins_pro);
        if($query_data){
            echo "<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Sales Successfully Added'
    data-type='success'>
    </div>";
        }

        }else{

        $selectincome_echo = "SELECT * FROM sales order by transaction_id DESC";
        $sql_query_echo = mysqli_query($conn,$selectincome_echo);
        $id_cash = mysqli_fetch_array('$sql_query_echo');
        $income = "RS-";
        $x = 000;
        $rs_comev = $income.''.$x.''.$id_cash['transaction_id'];

        $ins_pro = "INSERT INTO sales VALUES(NULL,'$rs_comev','$id_cash','$date','$mount','$cush','$qtyone')";
        $query_data = mysqli_query($conn,$ins_pro);

            if($query_data){

               echo "<div class='toast bg-success'
    data-title='Authentification Centre'
    data-message='Sales Successfully Added'
    data-type='success'>
    </div>";

            }

        }

    }

}

        $sqlselect= "SELECT * FROM products WHERE product_code = '$code_pro' AND id_branch = '$code_branch'";
        $results = mysqli_query($conn,$sqlselect);
        $now_status= mysqli_fetch_array($results);
        $now_status['product_id'];
        $cost=$now_status['selling_price'];

 ?>
<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
</head>
    <link rel="stylesheet" href="assets/css/app.css"> 

<body class="light sidebar-mini sidebar-collapse" >
  
  <?php 

    if ($id_cash =='cashier') {
       include 'includes/cashiernav.php'; 
    }else{
        include 'includes/nav.php'; 
    }
    

    ?>  

    <div class='has-sidebar-left has-sidebar-tabs'>

        <header class='my-3'>
            <div class='container-fluid'>
                <div class='row'>
                    <div class='col'>
                        <h1 class='s-2 mt-3'>
                            <center><?php include('system_name.php');?></center>
                          
                        </h1>
                    </div>
                </div>
            </div>
        </header>
        <div class='container-fluid my-3'>
          <div id="alldata">
              


     </div>

	  <div class='card my-3 no-b'>     
	        <div class='card-body'>
	<center><div class="table-responsive">
	 <h4 class="card-header">PRODUCTS IDENTIFICATIONS AND SALES</h4>
	</div>
    </center>           							
	<form  class="form-inline" method="post" id="notsubmit" >
	<div class="col-md-2">	
	<div class="form-group m-1 ">
	<label>Branch Name</label>
	<select name="branch" class="form-control col-md-12" >
		<?php
		
		$result = "SELECT * FROM branch where id='$userbranch'";
		$res=mysqli_query($conn,$result);
		while($fetch=mysqli_fetch_array($res)){
           
		?>
			<option value="<?php echo $fetch['id']; ?>" name='branch' id="branches"><?php echo $fetch['branch_name']; ?></option>
		<?php

		$x++;
			}
		?>
	</select>
	</div>
	</div>


	<div class="col-md-2">
	<div class="form-group">
		<labeL>Customer_code</label>
	<input type="text" name="cus_code" class="form-control col-md-12" value='<?php echo $_SESSION['cus']; ?>' required>
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group">
		<label>product_code</label>
	<input type="text" name="product_code" class="form-control col-md-12" value="" autofocus="on" required id="" onchange="fetchdata(this.value)">
	</div>
	</div>

	<!-- <div class="col-md-2">
	<div class="form-group">
		<label>product_code</label>
	<input type="text" name="pro_name" class="form-control col-md-12" value="blue brand" readonly>
	</div>
	</div> -->
	<div class="col-md-2">
	<div class="form-group">
		<label>Quantity</label>
    <input type="hidden" name="price" value="<?php echo $cost;?>" >
	<input type="number" name="qty" class="form-control col-md-12" required>
	</div>
	</div>

	<div class="col-md-2">
	<div class="form-group mt-4">
	<input type="submit" name="add" class="btn btn-primary col-md-12" value="Add To Cart">
	</div>
	</div>
	</div>	
	</form>


   <div class='card my-3 no-b'>
                
        <div class='card-body'>
                 	<center>
                        <h4 class="card-header">PRODUCT CART</h4></center>
                    <div class="table-responsive">
                    	
                        <table class="table table-hover">
                              
                            <thead>

                               <tr class="record">
                               <th>S/N</th>
                                <th>Customer_code</th>
                          		 <th>Product_code</th>
                                <th>Quantity</th>
                                <th>price solid</th>
                                <th>Sales</th>
                                <th>Remove</th>
                           		</tr>
                            </thead>
                            <tbody>
                            	<?php
                              $x=1;
                            	$y = 0 ;	
                             foreach ($_SESSION['cart'] as $value) {?>

                             	<tr>
                             		<td><?php  echo $x  ?></td>
                             		<td><?php echo $value['cush']  ?></td>
                             		<td><?php  echo $value['id']  ?></td>
                             		<td id="qty"><?php  echo $value['qty']  ?></td>
                                <td id="price"><?php echo $value['price'] ?></td>
                             		<td ><?php $cash = $value['qty']*$value['price']; echo $cash; ?></td>
                             		<td><a href='remove.php?code=<?php echo $y; ?>' class='btn btn-danger'>Remove</a></td>
                             	</tr>
                             	
                             <?php 
                             $y++;
                             $x++;
                           }
                          		?>
                            </tbody>
                        </table>
                       
                     </div>
              
                      <form method="POST">	

                        		<input type="submit" name="code" value="SAVE SALES" class="btn btn-primary">
                                <input type="submit" name="clear" value="CLEAR CART" class="btn btn-danger">

                        </form>
                 </div>
            </div>
        </div>


         </div>
     </div>
  </div>
</div> 
 </body>



 <script type="text/javascript">
   
function fetchdata(value,branch){

  xhr = new XMLHttpRequest();
   let branchcode=document.getElementById('branches').value;
  xhr.open('GET','fetchdata.php?valueone='+value+'&code_branch='+ branchcode,true);

  xhr.onload = function (){
    if (this.status == 200) {


     document.getElementById('alldata').innerHTML = this.responseText;
    }
  }

  xhr.send();
  console.log(xhr);

}

 </script>




     <script src="assets/js/app.js"></script>
</html>