<?php
include 'auth.php';
include('connect/connect.php');
include 'model/db_connection.php';
include 'model/userModel.php';
$total=new userModel();
$customertotal=$total->getCustomerTotal();
$productTotal=$total->getProductTotal();
$getBranchTotal=$total->getBranchTotal();
$getEmployeeTotal=$total->getEmployeeTotal();
$getSumExpense=$total->getSumExpense();
$getExpired=$total->getExpired();
$getTransfered=$total->getTransfered();
$getPurschasing=$total->getPurschasing();
$getProductNearToExpire=$total->getProductNearToExpire();
$getsells=$total->getsells();
?>
 <!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>PRODUCT INFORMATION TRACKING SYSTEM</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/app.css"> 
    <style>
        .diproper{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            
            z-index: 1;
            height: 100vh;
            background-color: rgba(0,0,0, 0.6);
        }
    </style>
</head>
<body class="light sidebar-mini sidebar-collapse">
    <div class="has-sidebar-left has-sidebar-tabs">
    <?php include("includes/nav.php");?>
<div class="card m-3  p-2" style=" box-shadow: 5px 5px 10px rgba(0,0,0, 0.1);">

	  <center><h2 class="card-header white" style="text-transform: uppercase;">PRODUCT INFORMATION TRACKING SYSTEM(MAIN DASHBOARD)</h2></center>
	<div class="card-body ">
	<div class="row no-gutters my-3 white ">
            <div class="col-md-4">
                <div class="p-5 deep-purple lighten-2 text-white">
                        <h6 class="font-weight-normal s-14">ALL CUSTOMERS</h6>
                    <h6><span class="s-48 font-weight-lighter text-primary sc-counter "><?php echo $customertotal; ?></span></h6>
                        <div class="float-right">
                                <!--<span class="icon icon-arrow_downward s-48"></span>-->
                            </div>
                    </div>
                    <div class="row p-2 s-18 text-center">
                        <div class="col-6 b-r"> 
                            <i class="icon icon-arrow_upward text-success mr-2"></i><div></div>
                        </div>
                        <div class="col-6"> 
                                <i class="icon icon-arrow_downward text-danger mr-2"></i> <div></div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 shadow">
                        <div class="p-5 bg-secondary text-white">
                                <h6 class="font-weight-normal s-14 ">AVAILABLE PRODUCT</h6>
                                <span class="s-48 font-weight-lighter text-primary sc-counter"><?php  echo $productTotal;?></span>
                                <div class="float-right">
                                        <!--<span class="icon icon-arrow_upward s-48"></span>-->
                                    </div>
                            </div>
                            <div class="row p-2 s-18 text-center">
                                <div class="col-6 b-r"> 
                                    <i class="icon icon-arrow_upward text-success mr-2"></i><div></div>
                                </div>
                                <div class="col-6"> 
                                        <i class="icon icon-arrow_downward text-danger mr-2"></i> <div></div>
                                </div>
                            </div>
                        </div>
                    
                <div class="col-md-4">
                <div class="p-5 deep-purple lighten-3 text-white">
                              <h6 class="font-weight-normal s-14">
                              ALL EXPIRED PRODUCTS</h6> <span class="s-48 
                              font-weight-lighter text-primary sc-counter"><?php echo $getExpired;?></span>
                        <div class="float-right">
                                <!--<span class="icon icon-arrow_downward s-48"></span>-->
                            </div>
                    </div>
                    <div class="row p-2 s-18 text-center">
                        <div class="col-6 b-r"> 
                            <i class="icon icon-arrow_upward text-success mr-2"></i><div></div>
                        </div>
                        <div class="col-6"> 
                                <i class="icon icon-arrow_downward text-danger mr-2"></i> <div></div>
                        </div>
                    </div>
                </div>

        </div>

	</div>
</div>
	
<div class="row m-1 " >
<div class='col-md-6 ' style=" margin-top:15px;">
<div class='card ' style=" margin-bottom: 10px;box-shadow: 5px 5px 10px rgba(0,0,0, 0.1);">
<h3 class='card-header bg-white'> <center>ALL MORE DETAILS</center></h3>
<div class='card-body'>
<div class='table-responsive'>
<table class="table table-hover  table-bordered" style="margin-left: -10px;">
     <thead>                   
                            
          <center><tr style="font-weight:bold;color: purple;text-transform: ;">
            
                <th>Registered Branch</th>
                 <th>Total Expenses(TSH)</th>
                 <th>Total Employee</th>
             </tr>
        </thead>
            <tbody> 
             <center>
        <center><tr style="font-weight:bold;font-size: 15px;">
            
            
    <td class='sc-counter' > <?php echo $getBranchTotal;?></td>     

    <td class='sc-counter'>  <?php echo $getSumExpense;?></td>   
     <td class='sc-counter'><?php echo $getEmployeeTotal;?></td>
</tr>

                    </tbody>
                </table>
                </div>
            </div>
    </div>
</div>
<div class='col-md-6' style=" margin-top:15px;">
<div class='card' style="box-shadow: 5px 5px 10px rgba(0,0,0, 0.1);">
<h3 class='card-header bg-white'> <center>INVENTORY DETAILS</center></h3>
<div class='card-body'>
<table class="table  table-hover table-bordered">
                                
                               <thead>
                                
                                   <center><tr style="font-weight: bold;color: purple;font-size: 15px;">
                                    <th>Total Amount Purschasing</th>  
                                   <th> Amount  from Products Sells</th>  
                                   <th>Transfered stock</th> </tr>
                               </center> 
                              
                                </thead>
                                <tbody>
                                 <tr>
                                 
                                 <center>
                                     <td class='sc-counter'><?php echo $getPurschasing;?></td>
                                     <td class='sc-counter'> <?php echo $getsells?></td>

                                    <td class='sc-counter'> <?php echo $getTransfered;?></td>



                                 </center>
                                  
                                </tr>
                               
                            </tbody>
                        </table>
                            
                        

</div>
</div>
</div>
               <div class="jumbotron col-12">
                       
                            <?php include("footer.php");?>
                    </div>
</div>
 <script src="assets/js/app.js"></script>
 
        </body>
        </html>
           