<?php 	

include('connect/connect.php');

if (isset($_POST['btn'])) {
	$pro_id = $_POST['id_pro'];
	$qty = $_POST['qty'];
	$branch = $_POST['branch'];
	$pre = $_POST['pre'];

	$sqlpro = "SELECT * FROM products WHERE product_id = '$pro_id'";
	$sqlresults = mysqli_query($conn,$sqlpro);
	$fetchpro = mysqli_fetch_array($sqlresults);

	$pro_num = $fetchpro['quantinty'];
	if ($pro_num > $qty) {
		$sql = "INSERT INTO tranfer VALUES (NULL,'$pro_id','$qty','$pre','$branch','unapproved')";
		$results = mysqli_query($conn,$sql);
		header('location:transfer1.php?text=success');
	}else{
		header('location:transfer1.php?idcheck="success"');	
	}

	
}

if (isset($_GET['idone']) && isset($_GET['id_now_branch'])&& isset($_GET['id_pre_branch'])) {
	$idcheck = $_GET['idone']; 
	$now_branch =  $_GET['id_now_branch']; 
	 $pre_branch =  $_GET['id_pre_branch'];

	 $sqlone = "SELECT * FROM tranfer WHERE now_branch = '$now_branch ' AND pre_branch = '$pre_branch ' AND id_transfer = '$idcheck'";
	 $resultsone = mysqli_query($conn,$sqlone);
	 $fetchone = mysqli_fetch_array($resultsone);
	 $qty = $fetchone['qty'];
	echo  $pro_id = $fetchone['id_product'];

	  $sqlone1 = "SELECT * FROM products WHERE id_branch = '$pre_branch ' AND product_id = ' $pro_id '";
	 $resultsone1 = mysqli_query($conn,$sqlone1);
	 $fetchone1 = mysqli_fetch_array($resultsone1);
	 $qty1 = $fetchone1['quantinty'];
	 $product_code = $fetchone1['product_code'];
	 $product_name = $fetchone1['prod_name'];
	 $purchasing_price = $fetchone1['purscasing_price'];
	 $category = $fetchone1['category_id'];
	 $tax =$fetchone1['tax_id'];
	 $selling = $fetchone1['selling_price'];
	 $arrival =$fetchone1['arrival'];
	 $expire = $fetchone1['expiry_date'];
	 $ingredient = $fetchone1['ingredient'];
	 $ingredient2 = $fetchone1['ingredient2'];

	 $remain_pro = $qty1 - $qty;

	 echo $remain_pro;

	 $sqlupdate = "UPDATE  products SET quantinty='$remain_pro' WHERE  product_id = '$pro_id '";
	 $resultspro = mysqli_query($conn,$sqlupdate);


	  $sqlupdatec = "UPDATE  tranfer SET status = 'Approved' WHERE id_transfer = '$idcheck'";
	 $resultsproc = mysqli_query($conn,$sqlupdatec);
	

	 $sqls = "INSERT INTO `products` (`product_id`, `product_code`, `prod_name`, `purscasing_price`, `quantinty`, `category_id`, `tax_id`, `selling_price`, `arrival`, `expiry_date`, `id_branch`,`ingredient`,`ingredient2`,`dig`) VALUES (NULL, '$product_code', '$product_name', '$purchasing_price', '$qty', '$category', '$tax', '$selling', '$arrival', '$expire', '$now_branch','$ingredient','$ingredient2','1')";
	$resultsv = mysqli_query($conn,$sqls);
	$ujumbe=base64_encode('success');

	header("location:TransferApprove1.php?ujumbe=".$ujumbe."");
	



}



 ?>