-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2021 at 12:51 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `user`, `pass`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(100) NOT NULL,
  `branch_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `branch_name`) VALUES
(23, 'KASULU'),
(25, 'KAGERA'),
(32, 'ARUSHA'),
(33, 'BARIADI'),
(35, 'KIBAHA'),
(36, 'SAME');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(200) NOT NULL,
  `category` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category`) VALUES
(2, 'SOFT DRINK'),
(3, 'DRY DRINK'),
(4, 'ELECTRONIC'),
(5, 'FOOD'),
(6, 'CHOCOLATE'),
(7, 'FRUITS'),
(8, 'SOAP'),
(9, 'CLEANERS'),
(10, 'ALCOHOL'),
(11, 'NON ALCOHOL'),
(12, 'PAIN KILLER'),
(13, 'SUGARY FOODS'),
(14, 'GRAINS'),
(15, 'MEAT');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `membership_number` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `address`, `contact`, `membership_number`) VALUES
(160, 'hope', 'ARUSHA', '255621339238', 151),
(161, 'machibbya', 'DAR ES SAALAM', '255621339237', 152),
(162, 'ESTER bakena', 'ARUSHA', '255621339237', 153),
(163, '787878', 'DAR ES SAALAM', '88989', 154);

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `expense_name` varchar(100) NOT NULL,
  `brnch_id` int(255) NOT NULL,
  `amount` int(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `id_expenses` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`expense_name`, `brnch_id`, `amount`, `date`, `note`, `id_expenses`) VALUES
('fuel  Of transport', 33, 20000, '2021-07-04', 'NONE', 30),
('fuel  Of transport', 32, 2000, '2021-06-28', 'NONE', 31),
('fuel  Of transport', 25, 40000, '2021-06-15', 'NONE', 33),
('food', 23, 6000, '2021-06-01', 'NONE', 34),
('transport', 33, 2000, '2021-06-15', 'NONE', 36),
('hhhhh', 35, 6000, '2021-07-13', 'NONE', 37);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_code` varchar(10000) NOT NULL,
  `prod_name` varchar(200) NOT NULL,
  `purscasing_price` varchar(200) NOT NULL,
  `quantinty` varchar(100) NOT NULL,
  `category_id` int(100) NOT NULL,
  `tax_id` int(100) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `arrival` varchar(100) NOT NULL,
  `expiry_date` varchar(500) NOT NULL,
  `id_branch` int(11) NOT NULL,
  `ingredient` varchar(255) NOT NULL,
  `ingredient2` varchar(200) NOT NULL,
  `dig` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_code`, `prod_name`, `purscasing_price`, `quantinty`, `category_id`, `tax_id`, `selling_price`, `arrival`, `expiry_date`, `id_branch`, `ingredient`, `ingredient2`, `dig`) VALUES
(194, '19980718200010001', 'OMO', '800', '456 ', 0, 2, '1000', '2021-06-20', '2021-09-12', 25, 'VITAMIN,CABOYHDRATE,WATER,SUGAR', 'ALCOHOL', 0),
(201, '19980718200010002', 'MTINDI FRESH', '1200', '249', 5, 2, '3000', '2021-06-14', '2021-09-05', 33, 'milk,water,sugar', 'vtamin E', 0),
(203, '19980718200010000', 'SAFARI LAGER', '1500', '811', 3, 2, '2000', '2021-06-17', '2022-07-30', 35, '10 potassium', '2 ph', 0),
(207, '19980718200010001', 'Soda', '300', '70 ', 5, 6, '3000', '2021-06-17', '2021-09-1', 35, '10 potassium', '2 ph', 0),
(210, '19980718200010001', 'Cloth', '3000000', '271', 5, 4, '200', '2021-06-30', '2021-06-30', 23, '10 potassium', '2 ph', 0),
(211, '19980718200010003', 'AZAM COLA', '2000', '500 ', 2, 2, '5000', '2021-06-17', '2022-09-06', 35, '10 potassium', '2ph', 0),
(214, '19980718200010001', 'SAFARI LAGER', '5000', '200 ', 3, 0, '10000', '2021-06-17', '2023-10-18', 32, '10 potassium', '2 ph', 0),
(216, '19980718200010008', 'SODA', '1000', '456 ', 2, 2, '4000', '2021-06-17', '2021-09-18', 25, '2 magnesium', '2 ph', 0),
(219, '19980718200010001', 'OMO', '3000', '4 ', 0, 0, '1000', '2021-06-20', '2023-01-12', 23, 'VITAMIN,CABOYHDRATE,WATER,SUGAR', 'ALCOHOL', 1),
(220, '19980718200010000', 'K VANT', '12000', '200', 0, 0, '15000', '2021-09-06', '2021-07-10', 32, 'VITAMIN,CABOYHDRATE,WATER,SUGAR', 'ALCOHOL 20', 1),
(221, '19980718200010000', 'MILK', '1500', '23', 0, 0, '4000', '2021-06-07', '2021-06-01', 23, 'milk,water,sugar', 'vtamin E', 1),
(222, '19980718200010008', 'maji', '20000', '9 ', 11, 0, '40000', '2021-06-17', '2021-06-17', 23, '2 magnesium', '2 ph', 1),
(223, '19980718200010000', 'K VANT', '12000', '130 ', 10, 0, '15000', '2021-09-06', '2021-08-10', 23, 'VITAMIN,CABOYHDRATE,WATER,SUGAR', 'ALCOHOL 20', 1),
(224, '19980718200010001', 'Cloth', '3000000', '3', 5, 4, '200', '2021-06-30', '2021-06-30', 23, '10 potassium', '2 ph', 1),
(225, '19980718200010000', 'MILK', '1500', '67', 0, 0, '4000', '2021-06-07', '2021-06-01', 23, 'milk,water,sugar', 'vtamin E', 1),
(227, '19980718200010000', 'K VANT', '12000', '78', 0, 0, '15000', '2021-09-06', '2021-07-10', 23, 'VITAMIN,CABOYHDRATE,WATER,SUGAR', 'ALCOHOL 20', 1),
(228, '19980718200010001', 'CHOCOLATE', '5000', '128 ', 13, 0, '10000', '2021-06-17', '2023-10-18', 23, '10 potassium', '2 ph', 1),
(234, '19980718200010001', 'Cloth', '3000000', '13', 5, 4, '200', '2021-06-30', '2021-06-30', 32, '10 potassium', '2 ph', 1),
(239, '19980718200010001', 'Cloth', '3000000', '13', 5, 4, '200', '2021-06-30', '2021-06-30', 25, '10 potassium', '2 ph', 1),
(247, '19980718200010004', 'SAFARI LAGER', '1500', '4 ', 10, 2, '2000', '2021-07-01', '2021-08-27', 32, 'milk,sugar', 'alcohol', 0),
(252, '19980718200010000', 'SAFARI LAGER', '1500', '89', 3, 2, '2000', '2021-06-17', '2022-07-30', 32, '10 potassium', '2 ph', 1),
(253, '19980718200010002', 'MTINDI FRESH', '1200', '78', 5, 2, '3000', '2021-06-14', '2021-09-05', 32, 'milk,water,sugar', 'vtamin E', 1),
(254, '19980718200010002', 'MTINDI FRESH', '1200', '3', 5, 2, '3000', '2021-06-14', '2021-09-05', 23, 'milk,water,sugar', 'vtamin E', 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `transaction_id` int(11) NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `suplier` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `transaction_id` int(11) NOT NULL,
  `invoice_number` varchar(100) NOT NULL,
  `cashier` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`transaction_id`, `invoice_number`, `cashier`, `date`, `amount`, `customer_id`, `qty`) VALUES
(153, 'RS-0', '', '2021-06-25', '260000', '100', '13'),
(154, 'RS-0', '', '2021-06-25', '260000', '100', '13'),
(155, 'RS-0', '', '2021-06-25', '100000', '100', '5'),
(156, 'RS-0', '', '2021-06-25', '1560000', '100', '78'),
(157, 'RS-0', '', '2021-06-25', '1780000', '100', '89');

-- --------------------------------------------------------

--
-- Table structure for table `sales_order`
--

CREATE TABLE `sales_order` (
  `transaction_id` int(11) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `product_code` varchar(150) NOT NULL,
  `gen_name` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `date` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_order`
--

INSERT INTO `sales_order` (`transaction_id`, `invoice`, `product`, `qty`, `amount`, `profit`, `product_code`, `gen_name`, `name`, `price`, `discount`, `date`) VALUES
(315, 'RS-3332223', '58', '9', '18000', '12600', 'abc', 'kilimanjaro', ' drinks', '2000', '', '05/18/21'),
(316, 'RS-506222', '58', '1', '2000', '1400', 'abc', 'kilimanjaro', ' drinks', '2000', '', '05/18/21'),
(318, 'RS-002022', '61', '5', '0', '0', '56756565', '', 'fdfdhgghhg', '', '', '05/21/21');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `id_sch` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `day` varchar(110) NOT NULL,
  `week` varchar(110) NOT NULL,
  `mon` int(11) NOT NULL,
  `years` int(11) NOT NULL,
  `date_sch` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`id_sch`, `employee_id`, `day`, `week`, `mon`, `years`, `date_sch`) VALUES
(48, 48, 'Monday', 'first week', 7, 2021, '04/07/2021');

-- --------------------------------------------------------

--
-- Table structure for table `supliers`
--

CREATE TABLE `supliers` (
  `suplier_id` int(11) NOT NULL,
  `suplier_name` varchar(100) NOT NULL,
  `suplier_address` varchar(100) NOT NULL,
  `suplier_contact` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `note` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supliers`
--

INSERT INTO `supliers` (`suplier_id`, `suplier_name`, `suplier_address`, `suplier_contact`, `contact_person`, `note`) VALUES
(5, 'KASULU', 'DAR ES SAALAM', '111111111', '9876543', '');

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

CREATE TABLE `tax` (
  `tax_id` int(200) NOT NULL,
  `tax_name` varchar(200) NOT NULL,
  `tax_amount` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`tax_id`, `tax_name`, `tax_amount`) VALUES
(2, 'NONE', '0'),
(3, 'VAT', '20');

-- --------------------------------------------------------

--
-- Table structure for table `tranfer`
--

CREATE TABLE `tranfer` (
  `id_transfer` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `pre_branch` int(11) NOT NULL,
  `now_branch` int(11) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'unapproved'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tranfer`
--

INSERT INTO `tranfer` (`id_transfer`, `id_product`, `qty`, `pre_branch`, `now_branch`, `status`) VALUES
(61, 194, 100, 25, 25, 'Approved'),
(62, 194, 4, 25, 23, 'Approved'),
(66, 216, 9, 25, 23, 'Approved'),
(68, 210, 3, 23, 23, 'Approved'),
(69, 221, 67, 23, 23, 'Approved'),
(70, 194, 78, 25, 23, 'Approved'),
(71, 220, 78, 32, 23, 'Approved'),
(72, 220, 60, 32, 23, 'unapproved'),
(73, 220, 80, 32, 23, 'unapproved'),
(74, 214, 12, 32, 23, 'Approved'),
(75, 210, 13, 23, 32, 'Approved'),
(76, 201, 1000, 33, 23, 'Approved'),
(77, 201, 3, 33, 23, 'Approved'),
(83, 210, 13, 23, 25, 'Approved'),
(84, 203, 89, 35, 32, 'Approved'),
(85, 201, 78, 33, 32, 'Approved'),
(86, 201, 78, 33, 33, 'unapproved'),
(87, 210, 78, 23, 23, 'unapproved'),
(88, 210, 13, 23, 23, 'unapproved');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `branch_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `name`, `contact`, `position`, `branch_id`) VALUES
(31, 'admin@admin.com', '12345678', 'Dominick  MATONANGE', '255677716683', 'admin', 0),
(41, 'hope@cashier.com', '12345678', 'HOPE ENOCK FUNKE', '255742042302', 'cashier', 32),
(46, 'baraka@cashier.com', '12345678', 'BARAKA MGHUMBA', '000000000', 'cashier', 32),
(48, 'hope@inventory.com', '12345678', 'ESTER MUZEHEE', '000000000', 'invetory', 32),
(49, 'baraka@inventory.com', '12345678', 'HOPE ENOCK FUNKE', '000000000083', 'Inventory', 32);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `position` varchar(100) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `stamp` varchar(255) NOT NULL,
  `id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`position`, `ip`, `action`, `stamp`, `id`) VALUES
('admin@admin.com', '127.0.0.1', 'Login Successfully', '09:03:38pm', 1),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '09:13:04pm', 2),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '09:22:37pm', 3),
('admin@admin.com', '::1', 'Login Successfully', '06:05:31am', 4),
('cashier', '::1', 'Login Successfully', '06:16:27am', 5),
('admin@admin.com', '::1', 'Login Successfully', '06:32:55am', 6),
('cashier', '::1', 'Login Successfully', '06:33:16am', 7),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '07:19:36am', 8),
('32', '127.0.0.1', 'Login Successfully', '07:19:57am', 9),
('cashier', '127.0.0.1', 'Login Successfully', '07:20:12am', 10),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '07:25:09am', 11),
('32', '127.0.0.1', 'Login Successfully', '07:25:23am', 12),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '07:56:08am', 13),
('cashier', '127.0.0.1', 'Login Successfully', '07:58:13am', 14),
('32', '127.0.0.1', 'Login Successfully', '07:58:51am', 15),
('cashier', '127.0.0.1', 'Login Successfully', '08:03:51am', 16),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '08:44:19am', 17),
('admin@admin.com', '::1', 'Login Successfully', '08:56:59am', 18),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '08:58:31am', 19),
('cashier', '127.0.0.1', 'Login Successfully', '09:01:18am', 20),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '09:14:32am', 21),
('cashier', '127.0.0.1', 'Login Successfully', '09:16:17am', 22),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '09:21:09am', 23),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '09:39:20am', 24),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '09:46:47am', 25),
('cashier', '127.0.0.1', 'Login Successfully', '09:53:33am', 26),
('32', '127.0.0.1', 'Login Successfully', '09:57:03am', 27),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '10:00:53am', 28),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '08:53:10pm', 29),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '12:52:23pm', 30),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '04:55:13pm', 31),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '05:38:01pm', 32),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '05:48:22pm', 33),
('admin@admin.com', '127.0.0.1', 'Login Successfully', '02:59:04pm', 34),
('cashier', '127.0.0.1', 'Login Successfully', '03:00:55pm', 35),
('admin@admin.com', '::1', 'Login Successfully', '06:35:27pm', 36),
('cashier', '127.0.0.1', 'Login Successfully', '06:52:31pm', 37),
('32', '127.0.0.1', 'Login Successfully', '07:09:07pm', 38);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `expense`
--
ALTER TABLE `expense`
  ADD PRIMARY KEY (`id_expenses`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `id_branch` (`id_branch`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `sales_order`
--
ALTER TABLE `sales_order`
  ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`id_sch`);

--
-- Indexes for table `supliers`
--
ALTER TABLE `supliers`
  ADD PRIMARY KEY (`suplier_id`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `tranfer`
--
ALTER TABLE `tranfer`
  ADD PRIMARY KEY (`id_transfer`),
  ADD KEY `id_product` (`id_product`),
  ADD KEY `now_branch` (`now_branch`),
  ADD KEY `pre_branch` (`pre_branch`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT for table `expense`
--
ALTER TABLE `expense`
  MODIFY `id_expenses` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=265;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `sales_order`
--
ALTER TABLE `sales_order`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=319;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `id_sch` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `supliers`
--
ALTER TABLE `supliers`
  MODIFY `suplier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tax`
--
ALTER TABLE `tax`
  MODIFY `tax_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tranfer`
--
ALTER TABLE `tranfer`
  MODIFY `id_transfer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`id_branch`) REFERENCES `branch` (`id`);

--
-- Constraints for table `tranfer`
--
ALTER TABLE `tranfer`
  ADD CONSTRAINT `tranfer_ibfk_1` FOREIGN KEY (`id_product`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `tranfer_ibfk_2` FOREIGN KEY (`now_branch`) REFERENCES `branch` (`id`),
  ADD CONSTRAINT `tranfer_ibfk_3` FOREIGN KEY (`pre_branch`) REFERENCES `branch` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
